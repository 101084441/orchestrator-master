using System;
using System.Threading.Tasks;
using Azure.Storage.Queues;
using Azure.Storage.Queues.Models;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace PatientEverything
{
    /// <summary>
    /// This class is responsible for triggering the ExecuteAsync function in every 15 seconds.
    /// </summary>
    public static class TriggerFunction
    {
        /// <summary>
        /// This method triggers in every 15 seconds
        /// </summary>
        /// <param name="myTimer"></param>
        /// <param name="log"></param>
        /// <returns></returns>
        [FunctionName("Function")]
        public static async Task RunAsync([TimerTrigger("*/15 * * * * *")] TimerInfo myTimer, ILogger log)
        {
            log.LogInformation($"C# Timer trigger function executed at: {DateTime.Now}");
            await ExecuteAsync(log);
        }
        /// <summary>
        /// This method is used to check for queue messages and work upon them.
        /// </summary>
        /// <param name="_logger"></param>
        /// <returns></returns>
        private static async Task ExecuteAsync(ILogger _logger)
        {
            QueueClient queueClient = new QueueClient(Environment.GetEnvironmentVariable("StorageConnectionString"), Environment.GetEnvironmentVariable("QueueName"));
            _logger.LogInformation("#######################################################");
            _logger.LogInformation("Reading from queue");

            QueueMessage queueMsg = await queueClient.ReceiveMessageAsync();
            TQueueMessage queueMessage = new TQueueMessage();
           
            if (queueMsg != null)
            {
                queueMessage.MessageId = queueMsg.MessageId;
                queueMessage.PopReceipt = queueMsg.PopReceipt;
                var data = JsonConvert.DeserializeObject<Data>(queueMsg.Body.ToString());
                string fileName = Utils.GenerateUUID(data);
                data.FileName = fileName;
                _logger.LogInformation("New Mesasge Read: {data}", queueMsg.Body);
                  if (data.Status.ToString().Equals(StatusConstant.NOT_STARTED))
                {
                    await Utils.UpdateQueue(queueMessage, data, StatusConstant.IN_PROCESS, null, _logger);
                    string accessToken = await PatientEverything.GetAccessTokenAsync(queueMessage, data, _logger);
                    if (accessToken != null)
                    {
                       await PatientEverything.GetPatientClinicalDetailsAsync(queueMessage, data,accessToken, _logger);
                       await Utils.UpdateQueue(queueMessage, data, StatusConstant.PROCESS_DONE, null, _logger);
                    }
                }
            }
        }
    }
}

