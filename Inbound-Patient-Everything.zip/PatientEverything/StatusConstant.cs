﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PatientEverything
{
    public static class StatusConstant
    {
        public const string NOT_STARTED = "Not Started";
        public const string IN_PROCESS = "In Process";
        public const string PROCESS_FAILED = "Process Failed";
        public const string PROCESS_RETRY = "Process Retry";
        public const string PROCESS_DONE = "Process Done";
        public const string COMPLETED = "Completed";
        public const string TERMINATED = "Terminated";

    }
}
