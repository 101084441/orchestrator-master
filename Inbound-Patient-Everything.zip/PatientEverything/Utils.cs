﻿using Azure;
using Azure.Storage.Queues;
using Azure.Storage.Queues.Models;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PatientEverything
{
    class Utils
    {
        /// <summary>
        /// This method is used to update the queue.
        /// </summary>
        /// <param name="queueClient"></param>
        /// <param name="queueMessage"></param>
        /// <param name="data"></param>
        /// <param name="_logger"></param>
        /// <param name="status"></param>
        /// <returns></returns>
        internal static async Task
            UpdateQueue(TQueueMessage queueMessage, Data data, string status, string msg, ILogger _logger)
        {
            QueueClient queueClient = new QueueClient(Environment.GetEnvironmentVariable("StorageConnectionString"), Environment.GetEnvironmentVariable("QueueName"));

            data.Status = status;
            data.MessageDescription = msg == null ? data.MessageDescription : msg;
            var uData = JsonConvert.SerializeObject(data);
            _logger.LogInformation("Updated Message: {data}", uData);
            Response<UpdateReceipt> response = await queueClient.UpdateMessageAsync(queueMessage.MessageId,
                        queueMessage.PopReceipt, uData, new TimeSpan(0, 0, 0));
            queueMessage.PopReceipt = response.Value.PopReceipt;

            _logger.LogInformation("Updated queue completed", queueMessage);
            //   _logger.LogInformation(queueMessage.PopReceipt.ToString(),response.Value.PopReceipt.ToString());

        }
        public static string GenerateUUID(Data data)
        {
            Guid result;
            string input = Environment.GetEnvironmentVariable("hash_key")+ data.CfRequestId + data.CfMemberLifeId + data.OtherPayerId;
            using (MD5 md5 = MD5.Create())
            {
                byte[] hash = md5.ComputeHash(Encoding.UTF8.GetBytes(input));
                result = new Guid(hash);
                Console.WriteLine("\t" + result);
            }
            return result.ToString();
        }
        public static byte[] ConvertToByteArray(string str, Encoding encoding)
        {
            return encoding.GetBytes(str);
        }

        public static String ToBinary(Byte[] data)
        {
            return string.Join(" ", data.Select(byt => Convert.ToString(byt, 2).PadLeft(8, '0')));
        }
    }
}
