﻿
using Azure;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Azure.Storage.Queues;
using Azure.Storage.Queues.Models;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace PatientEverything
{
    /// <summary>
    /// This class is reponsible for these functions:
    /// 1. Do $everything pagination api call to CF apigee API
    /// 2. Save clincal json part files in isolated blob store
    /// 3. If in response json resourceType="DocumentReference" then download the attachment and save isolated store
    /// </summary>
    public static class PatientEverything
    {
        

        /// <summary>
        /// This method is used for getting the azure acess token.
        /// </summary>
        /// <param name="queueMessage"></param>
        /// <param name="queueData"></param>
        /// <param name="_log"></param>
        /// <returns></returns>
        public static async Task<string> GetAccessTokenAsync(TQueueMessage queueMessage, Data queueData, ILogger _log)
        {
            _log.LogInformation(DateTime.Now + "Entering into GetAccessToken method.");
            string token = null;
            using (var client = new HttpClient())
            {
                var data = new[] { new KeyValuePair<string, string>("grant_type", "client_credentials"),
                    new KeyValuePair<string, string>("client_Id", Environment.GetEnvironmentVariable("client_Id")),
                    new KeyValuePair<string, string>("client_secret", Environment.GetEnvironmentVariable("client_secret")),
                    new KeyValuePair<string, string>("resource", Environment.GetEnvironmentVariable("resource")),
                };
                client.Timeout = TimeSpan.FromMinutes(5);
                var response = client.PostAsync(Environment.GetEnvironmentVariable("OAuth_URL") + Environment.GetEnvironmentVariable("adtenantId") + "/oauth2/token",
                  new FormUrlEncodedContent(data)
                );

                try
                {
                    response.Result.EnsureSuccessStatusCode();
                    var jsonString = response.Result.Content.ReadAsStringAsync();
                    var jsonObj = JObject.Parse(jsonString.Result);
                    token = jsonObj.GetValue("access_token").ToString();
                    //Environment.SetEnvironmentVariable("AccessToken", token);
                   // _log.LogInformation(DateTime.Now + " :Token set into environment variable.");
                }
                catch (Exception e)
                {
                    _log.LogError(DateTime.Now + " :Error fetching token");
                    _log.LogError(e.Message.ToString());
                    await Utils.UpdateQueue(queueMessage, queueData, StatusConstant.PROCESS_FAILED, e.Message.ToString(), _log);
                }
                finally
                {
                    _log.LogInformation(DateTime.Now + " :Exiting GetAccessToken method.");
                }
                return token;
            }
        }

        /// <summary>
        /// This method is responsible for Getting all the patient details with thir document references.
        /// </summary>
        /// <param name="queueMessage"></param>
        /// <param name="data"></param>
        /// <param name="_log"></param>
        /// <returns></returns>
        public static async Task GetPatientClinicalDetailsAsync(TQueueMessage queueMessage, Data data,string accessToken ,ILogger _log)
        {            
            _log.LogInformation("Entering into GetPatientDetails method");
            int sequence = 1;
            JObject jsonObj = null;
            string fhirId = data.PeFhirId;
            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer",accessToken);
                client.Timeout = TimeSpan.FromMinutes(5);
                var response = await client.GetAsync(Environment.GetEnvironmentVariable("fhir_URL") + "/Patient/" + fhirId + "/$everything"
                );
                try
                {
                    response.EnsureSuccessStatusCode();
                    var jsonString = response.Content.ReadAsStringAsync();
                    jsonObj = JObject.Parse(jsonString.Result);

                    await SaveInBlob(jsonObj, _log, queueMessage, data, 1,sequence);//saving the incoming json in BLOB API

                }

                catch (Exception e)
                {
                    await Utils.UpdateQueue(queueMessage, data, StatusConstant.PROCESS_FAILED, e.Message.ToString(), _log);
                    _log.LogError(e.Message.ToString());
                }
            }

            bool result = true;
            while (result)
            {
               
                var linkArray = jsonObj.GetValue("link") as JArray;
                var url = "";
                if (linkArray.Any(x => x["relation"].ToString().Equals("next")))
                {
                    url = linkArray.Select(x => x["url"].ToString()).FirstOrDefault();
                    using (var client = new HttpClient())
                    {
                        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
                        client.Timeout = TimeSpan.FromMinutes(5);
                        var response = await client.GetAsync(url);
                        try
                        {
                            response.EnsureSuccessStatusCode();
                            var jsonString = response.Content.ReadAsStringAsync();
                            jsonObj = JObject.Parse(jsonString.Result);
                            sequence++;
                            await SaveInBlob(jsonObj, _log, queueMessage, data, 1,sequence);//saving the incoming json in BLOB API
                            result = true;

                        }
                        catch (Exception e)
                        {
                            await Utils.UpdateQueue(queueMessage, data, StatusConstant.PROCESS_FAILED, e.Message.ToString(), _log);
                            _log.LogError(e.Message.ToString());
                        }

                        finally
                        {
                            _log.LogInformation("Exiting GetPatientDetails method.");
                        }
                    }
                }
                else
                    result = false;
            }

        }

        /// <summary>
        /// This method is responsible for saving the json or docref file as block blob in a container.
        /// </summary>
        /// <param name="jsonObj"></param>
        /// <param name="_log"></param>
        /// <param name="queueMessage"></param>
        /// <param name="data"></param>
        /// <param name="noOfAttempts"></param>
        /// <returns></returns>
        public static async Task SaveInBlob(JObject jsonObj, ILogger _log, TQueueMessage queueMessage, Data data, int noOfAttempts, int sequence)
        {
            // logic to download and save document references in BLOB API if any
            // Create a BlobServiceClient object which will be used to create a container client
            _log.LogInformation("Entering SaveInBlob method.");

            if (noOfAttempts <= 3)
            {
                try
                {
                    string connectionString = Environment.GetEnvironmentVariable("AzureBlobStorageAccount");
                    BlobServiceClient blobServiceClient = new BlobServiceClient(connectionString);

                    //get a BlobContainerClient
                    var containerClient = blobServiceClient.GetBlobContainerClient(data.CfLob.ToString().ToLower());

                    //you can check if the container exists or not, then determine to create it or not
                    bool isExist = containerClient.Exists();
                    if (!isExist)
                    {
                        await containerClient.CreateAsync();
                    }

                    //or you can directly use this method to create a container if it does not exist.
                    await containerClient.CreateIfNotExistsAsync();
                    var jsonString = JsonConvert.SerializeObject(jsonObj);
                    var timestamp = new DateTimeOffset(DateTime.UtcNow).ToUnixTimeMilliseconds();                  
                    string fileName =  data.FileName+"_"+timestamp+ ".json";

                    // Get a reference to a blob
                    BlobClient blobClient = containerClient.GetBlobClient(fileName);
                 
                    _log.LogInformation("Uploading to Blob storage as blob:\n\t {0}\n", blobClient.Uri);
                    BinaryData content = new BinaryData(jsonString);
                    await blobClient.UploadAsync(content, true);
                    //   await SetBlobPropertiesAsync(blobClient);
                    await AddBlobMetadataAsync(blobClient,queueMessage, data, _log,sequence);
                    var parameterArray = jsonObj.GetValue("entry") as JArray;
                    List<string> urlArray = new List<string>();
                    var contentType = "";
                    if (parameterArray != null)
                    {
                        foreach (var item in parameterArray)
                        {
                            if (item["resource"]["resourceType"].ToString().Equals("DocumentReference"))
                            {
                                foreach (var items in item["resource"]["content"])
                                {
                                    urlArray.Add(items["attachment"]["url"].ToString());
                                }
                                if (urlArray != null)
                                {
                                    foreach (var url in urlArray)
                                    {

                                       // var url = "https://upload.wikimedia.org/wikipedia/commons/thumb/3/38/Flower_July_2011-2_1_cropped.jpg/1200px-Flower_July_2011-2_1_cropped.jpg";

                                        contentType = url.ToString().Substring(url.ToString().LastIndexOf("."));
                                        string fileNameDocRef = data.FileName + "_" + timestamp + contentType;
                                       // string localFilePathDocRef = Path.Combine(localPathDocRef, fileNameDocRef);

                                        WebClient mywebClient = new WebClient();// to download the file from the uri
                                        //mywebClient.DownloadFile(url.ToString());
                                        Stream myBlob = new MemoryStream();
                                        myBlob = mywebClient.OpenRead(url.ToString());

                                        // Get a reference to a blob
                                        blobClient = containerClient.GetBlobClient(fileNameDocRef);

                                        _log.LogInformation("Uploading to Blob storage as blob:\n\t {0}\n", blobClient.Uri);

                                        // Upload data from the local file
                                        await blobClient.UploadAsync(myBlob, true);
                                        // await SetBlobPropertiesAsync(blobClient);
                                        await AddBlobMetadataAsync(blobClient, queueMessage, data, _log,sequence);
                                    }
                                }
                            }
                        }
                    }
                }
                catch (Exception e)
                {
                    //if (noOfAttempts != 3)
                    //{
                    //    await SaveInBlob(jsonObj, _log, queueMessage, data, noOfAttempts + 1, sequence);
                    //}
                    //else
                    {
                         await Utils.UpdateQueue(queueMessage, data, StatusConstant.IN_PROCESS, e.Message.ToString(), _log);
                         _log.LogError(e.Message.ToString());
                    }
                }

                finally
                {
                    _log.LogInformation("Exiting SaveInBlob method.");

                }
            }

        }

        /// <summary>
        /// This method is responsible for adding metadata info to each blob we save.
        /// </summary>
        /// <param name="blob"></param>
        /// <param name="queueMessage"></param>
        /// <param name="data"></param>
        /// <param name="_log"></param>
        /// <returns></returns>
        public static async Task AddBlobMetadataAsync(BlobClient blob,TQueueMessage queueMessage, Data data, ILogger _log, int sequence)
        {
            _log.LogInformation("Adding blob metadata.");
            try
            {

                IDictionary<string, string> metadata =
                   new Dictionary<string, string>();

                // Add metadata to the dictionary by calling the Add method
                metadata.Add("CF_REQUEST_ID", data.CfRequestId.ToString());
                metadata.Add("CF_MEMBER_ID", data.CfMemberLifeId.ToString());
                metadata.Add("CF_LOB", data.CfLob.ToString());
                metadata.Add("CF_FHIR_ID", data.FhirId.ToString());
                metadata.Add("OTHER_PAYER_ID", data.OtherPayerId.ToString());
                metadata.Add("OTHER_PAYER_NAME", data.OtherPayerName.ToString());
                metadata.Add("SEQUENCE_NUMBER", sequence.ToString());//page number
                metadata.Add("DOCUMENT_REFERENCE_FHIRID", "");
                metadata.Add("LAST_UPDATE_DATE", DateTime.Now.ToString());
                metadata.Add("OTHER_PAYER_MEMBER_FHIR_ID", data.PeFhirId);// to update Som
                // Set the blob's metadata.
                await blob.SetMetadataAsync(metadata);
            }
            catch (RequestFailedException e)
            {
                await Utils.UpdateQueue(queueMessage, data, StatusConstant.PROCESS_FAILED, e.Message.ToString(), _log);
                _log.LogError($"HTTP error code {e.Status}: {e.ErrorCode} \n Error Message: {e.Message}");
            }

            finally
            {
                _log.LogInformation("Exiting AddBlobMetadataAsync method.");
            }
        }
       
    }
}


