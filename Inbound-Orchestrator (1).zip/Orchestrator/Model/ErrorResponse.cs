﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Orchestrator.Model
{
    class ErrorResponse
    {
       
        public string Id { get; set; }
        public string ResourceType { get; set; }
        public string Code { get; set; }
        [JsonProperty(PropertyName = "issue")]
        public List<Issue> issue { get; set; }
    }
}
