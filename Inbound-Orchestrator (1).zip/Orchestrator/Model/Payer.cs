using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace Orchestrator.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class Payer {
    /// <summary>
    /// payer name
    /// </summary>
    /// <value>payer name</value>
    [DataMember(Name="payerName", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "payerName")]
    public string PayerName { get; set; }

    /// <summary>
    /// payer identifier
    /// </summary>
    /// <value>payer identifier</value>
    [DataMember(Name="payerRegistrationId", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "payerRegistrationId")]
    public string PayerRegistrationId { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Payer {\n");
      sb.Append("  PayerName: ").Append(PayerName).Append("\n");
      sb.Append("  PayerRegistrationId: ").Append(PayerRegistrationId).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
