﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Orchestrator
{
    public class LogMessage
    {
        public DateTime Date { get; set; } = DateTime.Now;
        public string Resource { get; set; } = "Orchestrator";
        public string Method { set; get; }
        public string Status { get; set; }
        public Identity Identity { set; get; }
        public string Description { get; set; }
        public string ToLogMessage()
        {
            
            return JsonConvert.SerializeObject(this, Formatting.None).ToString();
        }

    }

    public class Identity
    {
        public string CfRequestId { set; get; }
        public string CfMemberLifeId { set; get; }
        public string CfLob { set; get; }
        public string OtherPayerId { set; get; }
        public string OtherPayerName { set; get; }
        public string Status { set; get; }
    }
    public class LogMessageText
    {
        public DateTime Date { get; set; } = DateTime.Now;
        public string Resource { get; set; } = "Orchestrator";
        public string Method { set; get; }
        public string Status { get; set; }
        public string Description { get; set; }
        public string ToLogMessage()
        {

            return JsonConvert.SerializeObject(this, Formatting.None).ToString();
        }

    }


}
