using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace Orchestrator.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class PatientDataTransfer {
    /// <summary>
    /// trackingIdentifier
    /// </summary>
    /// <value>trackingIdentifier</value>
    [DataMember(Name="trackingIdentifier", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "trackingIdentifier")]
    public string TrackingIdentifier { get; set; }

    /// <summary>
    /// Gets or Sets RequestStatus
    /// </summary>
    [DataMember(Name="requestStatus", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "requestStatus")]
    public string RequestStatus { get; set; }

    /// <summary>
    /// request date time
    /// </summary>
    /// <value>request date time</value>
    [DataMember(Name="requestDatetime", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "requestDatetime")]
    public string RequestDatetime { get; set; }

    /// <summary>
    /// Gets or Sets Patient
    /// </summary>
    [DataMember(Name="patient", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "patient")]
    public Patient Patient { get; set; }

    /// <summary>
    /// Gets or Sets Payer
    /// </summary>
    [DataMember(Name="payer", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "payer")]
    public Payer Payer { get; set; }

    /// <summary>
    /// Gets or Sets OldCoverage
    /// </summary>
    [DataMember(Name="oldCoverage", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "oldCoverage")]
    public Coverage OldCoverage { get; set; }

    /// <summary>
    /// Gets or Sets Consent
    /// </summary>
    [DataMember(Name="consent", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "consent")]
    public List<Consent> Consent { get; set; }

    /// <summary>
    /// Gets or Sets AdditionalAttributes
    /// </summary>
    [DataMember(Name="additionalAttributes", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "additionalAttributes")]
    public AdditionalAttributes AdditionalAttributes { get; set; }

    /// <summary>
    /// audit Inserted By
    /// </summary>
    /// <value>audit Inserted By</value>
    [DataMember(Name="insertedBy", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "insertedBy")]
    public string InsertedBy { get; set; }

        /// <summary>
        /// audit Updated By
        /// </summary>
        /// <value>audit Updated By</value>
        [DataMember(Name = "updatedBy", EmitDefaultValue = false)]
        [JsonProperty(PropertyName = "updatedBy")]
        public string UpdatedBy { get; set; } = "Inbound Automation";

    /// <summary>
    /// Gets or Sets InsertedTimestamp
    /// </summary>
    [DataMember(Name="insertedTimestamp", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "insertedTimestamp")]
    public DateTime? InsertedTimestamp { get; set; }

    /// <summary>
    /// Gets or Sets LastUpdatedTimestamp
    /// </summary>
    [DataMember(Name="lastUpdatedTimestamp", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "lastUpdatedTimestamp")]
    public DateTime? LastUpdatedTimestamp { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class PatientDataTransfer {\n");
      sb.Append("  TrackingIdentifier: ").Append(TrackingIdentifier).Append("\n");
      sb.Append("  RequestStatus: ").Append(RequestStatus).Append("\n");
      sb.Append("  RequestDatetime: ").Append(RequestDatetime).Append("\n");
      sb.Append("  Patient: ").Append(Patient).Append("\n");
      sb.Append("  Payer: ").Append(Payer).Append("\n");
      sb.Append("  OldCoverage: ").Append(OldCoverage).Append("\n");
      sb.Append("  Consent: ").Append(Consent).Append("\n");
      sb.Append("  AdditionalAttributes: ").Append(AdditionalAttributes).Append("\n");
      sb.Append("  InsertedBy: ").Append(InsertedBy).Append("\n");
      sb.Append("  UpdatedBy: ").Append(UpdatedBy).Append("\n");
      sb.Append("  InsertedTimestamp: ").Append(InsertedTimestamp).Append("\n");
      sb.Append("  LastUpdatedTimestamp: ").Append(LastUpdatedTimestamp).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
