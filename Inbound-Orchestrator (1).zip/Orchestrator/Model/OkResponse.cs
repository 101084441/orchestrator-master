﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Orchestrator.Model
{
    class OkResponse
    {
        public string Response { get; set; }
        public string Status { get; set; }
        public string Code { get; set; }
        
    }
}
