﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace Orchestrator.Model
{
    class CfError
    {
        [DataMember(Name = "ErrorDetails", EmitDefaultValue = false)]
        [JsonProperty(PropertyName = "ErrorDetails")]
        public List<ErrorDetails> ErrorDetails { get; set; }
        public string code { get; set; }
    }
}

