using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace Orchestrator.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class ResponseContext {
    /// <summary>
    /// status of the request
    /// </summary>
    /// <value>status of the request</value>
    [DataMember(Name="status", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "status")]
    public string Status { get; set; }

    /// <summary>
    /// Gets or Sets Success
    /// </summary>
    [DataMember(Name="success", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "success")]
    public bool? Success { get; set; }

    /// <summary>
    /// GUID for the tracking request / Auditable purpose
    /// </summary>
    /// <value>GUID for the tracking request / Auditable purpose</value>
    [DataMember(Name="guid", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "guid")]
    public string Guid { get; set; }

    /// <summary>
    /// Gets or Sets ResponseTime
    /// </summary>
    [DataMember(Name="responseTime", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "responseTime")]
    public string ResponseTime { get; set; }

    /// <summary>
    /// Gets or Sets CurrentTimeStamp
    /// </summary>
    [DataMember(Name="currentTimeStamp", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "currentTimeStamp")]
    public DateTime? CurrentTimeStamp { get; set; }

    /// <summary>
    /// Gets or Sets Error
    /// </summary>
    [DataMember(Name="error", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "error")]
    public Error Error { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class ResponseContext {\n");
      sb.Append("  Status: ").Append(Status).Append("\n");
      sb.Append("  Success: ").Append(Success).Append("\n");
      sb.Append("  Guid: ").Append(Guid).Append("\n");
      sb.Append("  ResponseTime: ").Append(ResponseTime).Append("\n");
      sb.Append("  CurrentTimeStamp: ").Append(CurrentTimeStamp).Append("\n");
      sb.Append("  Error: ").Append(Error).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
