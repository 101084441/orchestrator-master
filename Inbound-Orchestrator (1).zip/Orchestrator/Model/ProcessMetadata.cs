﻿using Newtonsoft.Json;
using System;
using System.ComponentModel.DataAnnotations;


public class ProcessMetadata
{
    public string CfRequestId { get; set; }
    public string CfLob { get; set; }
    public string FhirId { get; set; }
    public string CfMemberLifeId { get; set; }
    public string OtherPayerId { get; set; }
    public string OtherPayerName { get; set; }
    public string OldCoverageId { get; set; }
    public string FileName { get; set; }
 
    public string Stage { get; set; }
    public string Status { get; set; }
    public string MessageDescription { get; set; }
    public string StartTime { get; set; }
    public string EndTime { get; set; }
    public string DocRefFhirId { get; set; }
    public string PeFhirId { get; set; }
    // public DateTime CreatedOn { get; set; }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson()
    {
        return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
public class CreateProcessMetadata
{
    [Required(ErrorMessage = "CF Request Id is required.")]
    public string CfRequestId { get; set; }
    public string CfLob { get; set; }
    public string FhirId { get; set; }
    public string CfMemberLifeId { get; set; }
    public string OtherPayerId { get; set; }
    public string OtherPayerName { get; set; }
    public string OldCoverageId { get; set; }
    public string Stage { get; set; }
    public string Status { get; set; }
    public string MessageDescription { get; set; }
  


    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson()
    {
        return JsonConvert.SerializeObject(this, Formatting.Indented);
    }
}
public class UpdateProcessMetadata
{
    public string FileName { get; set; } = null;
    public string Stage { get; set; } = null;
    public string Status { get; set; } = null;
    public string MessageDescription { get; set; } = null;
    public string DocRefFhirId { get; set; } = null;
    public string PeFhirId { get; set; }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson()
    {
        return JsonConvert.SerializeObject(this, Formatting.Indented);
    }
}