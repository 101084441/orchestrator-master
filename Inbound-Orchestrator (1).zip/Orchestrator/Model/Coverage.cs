using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace Orchestrator.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class Coverage {
    /// <summary>
    /// enrollee identifier
    /// </summary>
    /// <value>enrollee identifier</value>
    [DataMember(Name="enrolleeId", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "enrolleeId")]
    public string EnrolleeId { get; set; }

    /// <summary>
    /// enrollee first name
    /// </summary>
    /// <value>enrollee first name</value>
    [DataMember(Name="enrolleeFirstName", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "enrolleeFirstName")]
    public string EnrolleeFirstName { get; set; }

    /// <summary>
    /// enrollee last name
    /// </summary>
    /// <value>enrollee last name</value>
    [DataMember(Name="enrolleeMiddleName", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "enrolleeMiddleName")]
    public string EnrolleeMiddleName { get; set; }

    /// <summary>
    /// enrollee first name
    /// </summary>
    /// <value>enrollee first name</value>
    [DataMember(Name="enrolleeLastName", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "enrolleeLastName")]
    public string EnrolleeLastName { get; set; }

    /// <summary>
    /// coverage name
    /// </summary>
    /// <value>coverage name</value>
    [DataMember(Name="coverageName", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "coverageName")]
    public string CoverageName { get; set; }

    /// <summary>
    /// group
    /// </summary>
    /// <value>group</value>
    [DataMember(Name="group", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "group")]
    public string Group { get; set; }

    /// <summary>
    /// status
    /// </summary>
    /// <value>status</value>
    [DataMember(Name="status", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "status")]
    public string Status { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Coverage {\n");
      sb.Append("  EnrolleeId: ").Append(EnrolleeId).Append("\n");
      sb.Append("  EnrolleeFirstName: ").Append(EnrolleeFirstName).Append("\n");
      sb.Append("  EnrolleeMiddleName: ").Append(EnrolleeMiddleName).Append("\n");
      sb.Append("  EnrolleeLastName: ").Append(EnrolleeLastName).Append("\n");
      sb.Append("  CoverageName: ").Append(CoverageName).Append("\n");
      sb.Append("  Group: ").Append(Group).Append("\n");
      sb.Append("  Status: ").Append(Status).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
