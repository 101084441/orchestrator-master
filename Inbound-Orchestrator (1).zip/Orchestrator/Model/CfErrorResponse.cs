﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace Orchestrator.Model
{
    class CfErrorResponse
    {
        [DataMember(Name = "Error", EmitDefaultValue = false)]
        [JsonProperty(PropertyName = "Error")]
         public CfError CfError { get; set; }
    }
}

