﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Orchestrator.Model
{
    public class CheckNull
    {
        public StringBuilder NullFields { get; set; }
        public bool IsSuccess { get; set; }
    }
}
