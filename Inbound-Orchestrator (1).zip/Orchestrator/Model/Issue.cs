﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Orchestrator.Model
{
    class Issue
    {
        public string Code { get; set; }
        public string Diagnostics { get; set; }

    }
}
