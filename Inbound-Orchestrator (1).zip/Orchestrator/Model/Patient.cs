using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace Orchestrator.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class Patient {
    /// <summary>
    /// member life id
    /// </summary>
    /// <value>member life id</value>
    [DataMember(Name="memberLifeId", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "memberLifeId")]
    public string MemberLifeId { get; set; }

    /// <summary>
    /// user id
    /// </summary>
    /// <value>user id</value>
    [DataMember(Name="userId", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "userId")]
    public string UserId { get; set; }

    /// <summary>
    /// email id
    /// </summary>
    /// <value>email id</value>
    [DataMember(Name="emailId", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "emailId")]
    public string EmailId { get; set; }

    /// <summary>
    /// subject id
    /// </summary>
    /// <value>subject id</value>
    [DataMember(Name="subjectId", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "subjectId")]
    public string SubjectId { get; set; }

    /// <summary>
    /// member first name
    /// </summary>
    /// <value>member first name</value>
    [DataMember(Name="memberFirstName", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "memberFirstName")]
    public string MemberFirstName { get; set; }

    /// <summary>
    /// member last name
    /// </summary>
    /// <value>member last name</value>
    [DataMember(Name="memberLastName", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "memberLastName")]
    public string MemberLastName { get; set; }

    /// <summary>
    /// date of birth
    /// </summary>
    /// <value>date of birth</value>
    [DataMember(Name="memberDob", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "memberDob")]
    public string MemberDob { get; set; }

    /// <summary>
    /// gender
    /// </summary>
    /// <value>gender</value>
    [DataMember(Name="gender", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "gender")]
    public string Gender { get; set; }

    /// <summary>
    /// personal rep first name
    /// </summary>
    /// <value>personal rep first name</value>
    [DataMember(Name="personalRepFirstName", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "personalRepFirstName")]
    public string PersonalRepFirstName { get; set; }

    /// <summary>
    /// personal rep last name
    /// </summary>
    /// <value>personal rep last name</value>
    [DataMember(Name="personalRepLastName", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "personalRepLastName")]
    public string PersonalRepLastName { get; set; }

    /// <summary>
    /// user type
    /// </summary>
    /// <value>user type</value>
    [DataMember(Name="userType", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "userType")]
    public string UserType { get; set; }

    /// <summary>
    /// Gets or Sets Lob
    /// </summary>
    [DataMember(Name="lob", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "lob")]
    public string Lob { get; set; }

    /// <summary>
    /// fhir Id
    /// </summary>
    /// <value>fhir Id</value>
    [DataMember(Name="fhirId", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "fhirId")]
    public string FhirId { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Patient {\n");
      sb.Append("  MemberLifeId: ").Append(MemberLifeId).Append("\n");
      sb.Append("  UserId: ").Append(UserId).Append("\n");
      sb.Append("  EmailId: ").Append(EmailId).Append("\n");
      sb.Append("  SubjectId: ").Append(SubjectId).Append("\n");
      sb.Append("  MemberFirstName: ").Append(MemberFirstName).Append("\n");
      sb.Append("  MemberLastName: ").Append(MemberLastName).Append("\n");
      sb.Append("  MemberDob: ").Append(MemberDob).Append("\n");
      sb.Append("  Gender: ").Append(Gender).Append("\n");
      sb.Append("  PersonalRepFirstName: ").Append(PersonalRepFirstName).Append("\n");
      sb.Append("  PersonalRepLastName: ").Append(PersonalRepLastName).Append("\n");
      sb.Append("  UserType: ").Append(UserType).Append("\n");
      sb.Append("  Lob: ").Append(Lob).Append("\n");
      sb.Append("  FhirId: ").Append(FhirId).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
