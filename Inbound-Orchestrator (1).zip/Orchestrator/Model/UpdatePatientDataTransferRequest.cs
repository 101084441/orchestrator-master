using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace Orchestrator.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class UpdatePatientDataTransferRequest {
    /// <summary>
    /// trackingIdentifier
    /// </summary>
    /// <value>trackingIdentifier</value>
    [DataMember(Name="trackingIdentifier", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "trackingIdentifier")]
    public string TrackingIdentifier { get; set; }

    /// <summary>
    /// Gets or Sets RequestStatus
    /// </summary>
    [DataMember(Name="requestStatus", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "requestStatus")]
    public string RequestStatus { get; set; }

    /// <summary>
    /// request status description
    /// </summary>
    /// <value>request status description</value>
    [DataMember(Name="requestStatusDesc", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "requestStatusDesc")]
    public string RequestStatusDesc { get; set; }

    /// <summary>
    /// Last Updated By
    /// </summary>
    /// <value>Last Updated By</value>
    [DataMember(Name= "updatedBy", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "updatedBy")]
    public string UpdatedBy { get; set; }

    /// <summary>
    /// retry count
    /// </summary>
    /// <value>retry count</value>
    [DataMember(Name="retryCount", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "retryCount")]
    public string RetryCount { get; set; }


    ///// <summary>
    ///// Get the string presentation of the object
    ///// </summary>
    ///// <returns>String presentation of the object</returns>
    //public override string ToString()  {
    //  var sb = new StringBuilder();
    //  sb.Append("class UpdatePatientDataTransferRequest {\n");
    //  sb.Append("  TrackingIdentifier: ").Append(TrackingIdentifier).Append("\n");
    //  sb.Append("  RequestStatus: ").Append(RequestStatus).Append("\n");
    //  sb.Append("  RequestStatusDesc: ").Append(RequestStatusDesc).Append("\n");
    //  sb.Append("  UpdatedBy: ").Append(UpdatedBy).Append("\n");
    //  sb.Append("  RetryCount: ").Append(RetryCount).Append("\n");
    //  sb.Append("}\n");
    //  return sb.ToString();
    //}

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
