using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Orchestrator.API;
using Orchestrator.Constants;
using Orchestrator.Model;
using Orchestrator.Queue;
using Orchestrator.Util;


namespace Orchestrator.Trigger
{
    /// <summary>
    /// This class is responsible for polling from response queue every 30 seconds
    /// </summary>
    public static class TimeTrigger
    {
        /// <summary>
        /// This method is triggered in every 30 seconds
        /// </summary>
        /// <param name="myTimer"></param>
        /// <param name="_logger"></param>
        /// <returns></returns>
        [FunctionName("ReadResponseQueues")]
        public static async Task RunAsync([TimerTrigger("%TimerQueueReads%")] TimerInfo myTimer, ILogger _logger)
        {
          //  _logger.LogInformation($"C# Timer trigger function executed at: {DateTime.Now}");
            //create objects for all queues to keep polling for new request
            MemberResolutionQueue memberResolutionQueue = new MemberResolutionQueue();
            await memberResolutionQueue.ReadAsync(_logger);
            PatientEverythingQueue patientEverythingQueue = new PatientEverythingQueue();
            await patientEverythingQueue.ReadAsync(_logger);
            SecurityCheckQueue securityCheckQueue = new SecurityCheckQueue();
            await securityCheckQueue.ReadAsync(_logger);
            DocumentRefQueue documentRefQueue = new DocumentRefQueue();
            await documentRefQueue.ReadAsync(_logger);
        }
    }
}
