using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Orchestrator.API;
using Orchestrator.Constants;
using Orchestrator.Model;
using Orchestrator.Queue;
using Orchestrator.Util;


namespace Orchestrator.Trigger
{
    /// <summary>
    /// This class in reponsible to fetch new member requests from CF , update metadata, queues and CF
    /// </summary>
    public static class CfMemberRequestTimeTrigger
    {
        /// <summary>
        /// This method triggers a timer trigger every 1 second
        /// </summary>
        /// <param name="myTimer"></param>
        /// <param name="_logger"></param>
        /// <returns></returns>
        [FunctionName("CfMemberRequest")]
        public static async Task RunAsync([TimerTrigger("%TimerCfMemberApiCall%")] TimerInfo myTimer, ILogger _logger)
        {
            _logger.LogInformation($"C# Timer trigger function executed at: {DateTime.Now}");
           
            ObjectConverter objectConverter = new ObjectConverter();
            PatientDataTransfer patientDataTransfer = new PatientDataTransfer();
            string token = await TokenGenerator.GetAccessTokenAsync(_logger); // Get CF MemberRequest API token
            if (token != null)
            {
                try
                {                    
                    PatientDataTransferResponse patientDataTransferResponse = await CfMemberRequestApi.GetByCfMemberRequestApi(_logger, token); // Rest API call to CF MemberRequest API
                    // Check if we have new or retry requests
                    if (patientDataTransferResponse.PatientDataTransferList == null)
                    {
                        string logMessage = ObjectConverter.CreateLogMessageObject("Orchestrator", LogConstant.INFORMATION, "No new request found.", null);
                        _logger.LogInformation(logMessage); // no new or retry request
                    }
                    else
                    {
                        // Got new or retry request from CF MemberRequest API
                        using (var client = new HttpClient())
                        {
                            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                            client.Timeout = TimeSpan.FromMinutes(5);
                            var requests = patientDataTransferResponse.PatientDataTransferList
                                           .Select(x => x).OrderBy(y => y.RequestDatetime).ToList(); // order inbound requests wrt to request dateTime in desc order

                            var count = Utils.GetTaskCount(requests.Count);
                            for (int i = 0; i < count; i++) //max request count
                            {
                                patientDataTransfer = requests[i];
                                patientDataTransfer.UpdatedBy = FunctionConstant.INBOUND_AUTOMATION;
                                
                                // Check if its a new request or retry
                                if (patientDataTransfer.RequestStatus == StatusConstant.NOT_STARTED) // new request
                                    await NewRequestAsync(patientDataTransfer, _logger);                              
                                else // retry request
                                {       // Check if cf member request retry count if less/equal to set limit
                                    if (Convert.ToInt32(patientDataTransfer.AdditionalAttributes.Retrycount) <= Convert.ToInt32(Environment.GetEnvironmentVariable("MaxRetryCount"))) 
                                    {
                                        List<ProcessMetadata> processData =
                                                await MetadataApi.GetByProcessMetadata("cfRequestId", patientDataTransfer.TrackingIdentifier, _logger); // Get the process info from process metadata api                                     
                                        if (processData.Count != 0)  // if cf request exist in process metadata
                                        {
                                            if (processData[0].Status == StatusConstant.PROCESS_FAILED)
                                                await RetryRequestAsync(patientDataTransfer, processData[0], _logger);
                                            else
                                                await RequestAlreadyInProcessAsync(patientDataTransfer, processData[0], _logger);
                                        }
                                        else 
                                            await NewRequestAsync(patientDataTransfer, _logger);// start from 1st step
                                    }
                                    else 
                                        await UpdateCfAsTerminatedAsync(patientDataTransfer, _logger); // Updated cf member requst as terminated due to exceeding retry count
                                }
                                                                
                            }
                        }
                    }
                   
                }
                catch (Exception ex)
                {
                    //--Need to check
                    string logMessage = ObjectConverter.CreateLogMessageObject("RunAsync", LogConstant.ERROR, "" + ex.ToString(),null);
                    _logger.LogError(logMessage);
                    //_logger.LogError(ex.ToString());
                }
            }            
          

        }

        /// <summary>
        /// This method retries the failed member request
        /// </summary>
        /// <param name="patientDataTransfer"></param>
        /// <param name="processData"></param>
        /// <param name="_logger"></param>
        /// <returns></returns>
        public static async Task RetryRequestAsync(PatientDataTransfer patientDataTransfer,ProcessMetadata processData,ILogger _logger) {
            MemberResolutionQueue memberResolutionQueue = new MemberResolutionQueue();
            PatientEverythingQueue patientEverythingQueue = new PatientEverythingQueue();
            SecurityCheckQueue securityCheckQueue = new SecurityCheckQueue();
            DocumentRefQueue documentRefQueue = new DocumentRefQueue();
            ObjectConverter objectConverter = new ObjectConverter();
            string retryCount =(Convert.ToInt32(patientDataTransfer.AdditionalAttributes.Retrycount) + 1).ToString();
            patientDataTransfer.AdditionalAttributes.Retrycount = retryCount;
            QueueData queueData = objectConverter.ProcessMetadataToQueueData(patientDataTransfer, processData);
            string logMessage = ObjectConverter.CreateLogMessageObject("RetryRequestAsync", LogConstant.INFORMATION, "Retry Request. Retry Count: "+retryCount, queueData);
            _logger.LogInformation(logMessage);
            
            UpdatePatientDataTransferRequest updatePatientDataTransferRequest = objectConverter.UpdatePatientDataTransferRequest
                                                       (patientDataTransfer.UpdatedBy, StatusConstant.IN_PROCESS,
                                                       "Process Started", patientDataTransfer.AdditionalAttributes.Retrycount,
                                                       patientDataTransfer.TrackingIdentifier);
            await CfMemberRequestApi.PutCfMemberRequestApi(updatePatientDataTransferRequest, patientDataTransfer.TrackingIdentifier,queueData, _logger);//cf request id is tracking identifier
            UpdateProcessMetadata updateProcessMetadata =
                       objectConverter.ProcessMetadataUpdate(
                           null, StatusConstant.IN_PROCESS, "Process Restarted", processData.FhirId, null, null);
            OkResponse okResponse = await MetadataApi.PutProcessMetadata(updateProcessMetadata, processData.CfRequestId, _logger);
            if (okResponse.Code.Equals("OK"))
            {
                
                if (processData.Stage.Equals(FunctionConstant.MEMBER_RESOLUTION))
                    await memberResolutionQueue.AddQueueAsync(queueData, _logger);
                else if (processData.Stage.Equals(FunctionConstant.PATIENT_EVERYTHING))
                    await patientEverythingQueue.AddQueueAsync(queueData, _logger);
                else if (processData.Stage.Equals(FunctionConstant.SECURITY_CHECK))
                    await securityCheckQueue.AddQueueAsync(queueData, _logger);
                else if (processData.Stage.Equals(FunctionConstant.DOCUMENT_REFERENCE))
                    await documentRefQueue.AddQueueAsync(queueData, _logger);
            }
            else
            {
                 updatePatientDataTransferRequest = objectConverter.UpdatePatientDataTransferRequest
                          (patientDataTransfer.UpdatedBy, StatusConstant.IN_PROCESS,
                          "Process metadata api failed to update.", patientDataTransfer.AdditionalAttributes.Retrycount,
                          patientDataTransfer.TrackingIdentifier);
                await CfMemberRequestApi.PutCfMemberRequestApi(updatePatientDataTransferRequest, patientDataTransfer.TrackingIdentifier, queueData, _logger);
            }
        }

        /// <summary>
        /// This method processes the new request
        /// </summary>
        /// <param name="patientDataTransfer"></param>
        /// <param name="_logger"></param>
        /// <returns></returns>
        public static async Task NewRequestAsync(PatientDataTransfer patientDataTransfer, ILogger _logger)
        {
            MemberResolutionQueue memberResolutionQueue = new MemberResolutionQueue();
            ObjectConverter objectConverter = new ObjectConverter();
            QueueData queueData = objectConverter.PatientDataTansferToQueueData(patientDataTransfer, FunctionConstant.MEMBER_RESOLUTION);
            string logMessage = ObjectConverter.CreateLogMessageObject("NewRequestAsync", LogConstant.INFORMATION, "New Request.", queueData);
            _logger.LogInformation(logMessage);

            CheckNull fieldsValidated = objectConverter.CheckForNullFromCFInputs(patientDataTransfer); // Validate Fields

            if (fieldsValidated.IsSuccess)
            {
                CreateProcessMetadata createProcessMetadata = objectConverter.PatientDataTansferToProcessMetadata(patientDataTransfer);
                OkResponse response = await MetadataApi.PostProcessMetadata(createProcessMetadata, _logger);
                if (response.Code.Equals("OK"))
                {
                    // add MR
                    // business logic
                    UpdatePatientDataTransferRequest updatePatientDataTransferRequest = objectConverter.UpdatePatientDataTransferRequest
                                                                                        (patientDataTransfer.UpdatedBy, StatusConstant.IN_PROCESS,
                                                                                        "Process Started", patientDataTransfer.AdditionalAttributes.Retrycount,
                                                                                        patientDataTransfer.TrackingIdentifier);
                    
                    OkResponse okResponse = await CfMemberRequestApi.PutCfMemberRequestApi(
                                            updatePatientDataTransferRequest, patientDataTransfer.TrackingIdentifier, 
                                            queueData, _logger);//cf request id is tracking identifier
                    if (okResponse.Code.Equals("OK"))
                    {

                        await memberResolutionQueue.AddQueueAsync(queueData, _logger);
                    }
                    else
                    {
                         logMessage = ObjectConverter.CreateLogMessageObject("NewRequestAsync", LogConstant.ERROR, "Unable to start. Cf member request api thrown exception",null);
                        _logger.LogInformation(logMessage);
                    }
                }
                else
                    await Utils.MetadataPostApiFailAsync("NewRequestAsync",queueData,response,_logger);
            }
            else
                await Utils.NullCheckFailAsync("NewRequestAsync", queueData, fieldsValidated.NullFields,patientDataTransfer, _logger);
        }

        /// <summary>
        /// This method updates CF for terminated operation
        /// </summary>
        /// <param name="patientDataTransfer"></param>
        /// <param name="_logger"></param>
        /// <returns></returns>
        public static async Task UpdateCfAsTerminatedAsync(PatientDataTransfer patientDataTransfer, ILogger _logger)
        {
            ObjectConverter objectConverter = new ObjectConverter();
            UpdatePatientDataTransferRequest updatePatientDataTransferRequest = objectConverter.UpdatePatientDataTransferRequest
                                                                                                                 (patientDataTransfer.UpdatedBy, StatusConstant.TERMINATED,
                                                                                                                 "Process terminated as retry count is exceeding",
                                                                                                                 patientDataTransfer.AdditionalAttributes.Retrycount,
                                                                                                                 patientDataTransfer.TrackingIdentifier);
            QueueData queueData = new QueueData();
            queueData.CfRequestId = patientDataTransfer.TrackingIdentifier;
            queueData.CfMemberLifeId = patientDataTransfer.Patient.Lob;
            await CfMemberRequestApi.PutCfMemberRequestApi(updatePatientDataTransferRequest, patientDataTransfer.TrackingIdentifier, queueData, _logger);
        }

        /// <summary>
        /// This method updates to CF that the request is in still in process
        /// </summary>
        /// <param name="patientDataTransfer"></param>
        /// <param name="processMetadata"></param>
        /// <param name="_logger"></param>
        /// <returns></returns>
        public static async Task RequestAlreadyInProcessAsync(PatientDataTransfer patientDataTransfer,ProcessMetadata processMetadata, ILogger _logger) {
            QueueData queueData = new QueueData();
            queueData.CfLob = processMetadata.CfLob;
            queueData.CfMemberLifeId = processMetadata.CfMemberLifeId;
            queueData.CfRequestId = processMetadata.CfRequestId;
            queueData.OtherPayerId = patientDataTransfer.Payer.PayerRegistrationId;
            queueData.OtherPayerName = patientDataTransfer.Payer.PayerName;
            queueData.Status = processMetadata.Status;
            string logMessage = ObjectConverter.CreateLogMessageObject("Orchestrator", LogConstant.INFORMATION, "Request already in queue. In stage: " + processMetadata.Stage + " status: " + queueData.Status, queueData);
            _logger.LogInformation(logMessage); // no new or retry request

            if (processMetadata.Status == StatusConstant.COMPLETED || processMetadata.Status == StatusConstant.TERMINATED) {
                ObjectConverter objectConverter = new ObjectConverter();
                UpdatePatientDataTransferRequest updatePatientDataTransferRequest = objectConverter.UpdatePatientDataTransferRequest
                                                                                                                     (patientDataTransfer.UpdatedBy, processMetadata.Status,
                                                                                                                     processMetadata.MessageDescription,
                                                                                                                     patientDataTransfer.AdditionalAttributes.Retrycount,
                                                                                                                     patientDataTransfer.TrackingIdentifier);
                 logMessage = ObjectConverter.CreateLogMessageObject("Orchestrator", LogConstant.INFORMATION, "Updating Cf member requst api. Because request status: " + queueData.Status, queueData);
                _logger.LogInformation(logMessage); 
                await CfMemberRequestApi.PutCfMemberRequestApi(updatePatientDataTransferRequest, patientDataTransfer.TrackingIdentifier, queueData, _logger);
            }
     
        }
    }
   
}
