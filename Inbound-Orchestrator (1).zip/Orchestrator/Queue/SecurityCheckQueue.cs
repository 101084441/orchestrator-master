using System;
using System.Net;
using System.Threading.Tasks;
using Azure;
using Azure.Storage.Queues;
using Azure.Storage.Queues.Models;
using MemberMatch;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Orchestrator.API;
using Orchestrator.Constants;
using Orchestrator.Model;
using Orchestrator.Util;

namespace Orchestrator.Queue
{
    /// <summary>
    /// This class is used to poll security queue and do necessary CRUD operations
    /// </summary>
    public class SecurityCheckQueue
    {
        private  QueueClient queueClient = new QueueClient(Environment.GetEnvironmentVariable("SecurityCheckStorageConnectionString"), Environment.GetEnvironmentVariable("SecurityCheckResponseQueue"));


        /// <summary>
        /// Read a Queue Object
        /// </summary>
        /// <param name="_logger"></param>
        /// <returns></returns>
        public async Task ReadAsync(ILogger _logger)
        {

            QueueMessage queueMsg = await queueClient.ReceiveMessageAsync();
            TQueueMessage queueMessage = new TQueueMessage();
            if (queueMsg != null)
            {
                queueMessage.MessageId = queueMsg.MessageId;
                queueMessage.PopReceipt = queueMsg.PopReceipt;
                var data = JsonConvert.DeserializeObject<QueueData>(queueMsg.Body.ToString());
                if (data.Status.ToString().Equals(StatusConstant.PROCESS_DONE))
                {
                    string logMessage =
                       ObjectConverter.CreateLogMessageObject("SecurityCheckQueue", LogConstant.INFORMATION, "Process Done", data);
                    _logger.LogInformation(logMessage);
                    // Business Logic
                    ObjectConverter objectConverter = new ObjectConverter();
                    // create update payload for metadata api
                    UpdateProcessMetadata updateProcessMetadata =
                        objectConverter.ProcessMetadataUpdate(
                            FunctionConstant.DOCUMENT_REFERENCE, StatusConstant.IN_PROCESS, data.MessageDescription, data.PeFhirId, data.DocumentRefId, data.FileName);
                    data.Status = StatusConstant.NOT_STARTED;
                    data.Stage = FunctionConstant.DOCUMENT_REFERENCE;
                    // call the update metadata api
                    OkResponse response = await MetadataApi.PutProcessMetadata(updateProcessMetadata, data.CfRequestId, _logger);
                    if (response.Code.Equals("OK"))
                    {
                        // check if ok // not implemented
                        DocumentRefQueue documentRefQueue = new DocumentRefQueue();
                        await documentRefQueue.AddQueueAsync(data, _logger);
                    }
                    else
                    {
                        await Utils.MetadataApiFailAsync("SecurityCheckQueue", data, _logger);
                    }
                }
                else if (data.Status.ToString().Equals(StatusConstant.PROCESS_FAILED))
                {
                    await Utils.ProcessFailedAsync("SecurityCheckQueue", data, FunctionConstant.SECURITY_CHECK, _logger);
                }
                else if (data.Status.ToString().Equals(StatusConstant.TERMINATED))
                {
                    await Utils.ProcessTerminatedAsync("SecurityCheckQueue", data, FunctionConstant.SECURITY_CHECK, _logger);
                }
                await DeleteQueueAsync(queueMessage, _logger);
            }

        }
        /// <summary>
        /// Get queue client object
        /// </summary>
        /// <returns></returns>
        public  QueueClient GetQueueClient()
        {
              return queueClient;
        }
        /// <summary>
        /// Update a Queue Object
        /// </summary>
        /// <param name="queueMessage"></param>
        /// <param name="data"></param>
        /// <param name="_logger"></param>
        /// <returns></returns>
        public async Task UpdateQueueAsync(TQueueMessage queueMessage, QueueData data, ILogger _logger)
        {          

            var uData = JsonConvert.SerializeObject(data);
            Response<UpdateReceipt> response = await queueClient.UpdateMessageAsync(queueMessage.MessageId,
                        queueMessage.PopReceipt, uData, new TimeSpan(0, 0, 0));
            queueMessage.PopReceipt = response.Value.PopReceipt;
            string logMessage =
                       ObjectConverter.CreateLogMessageObject(FunctionConstant.SECURITY_CHECK, LogConstant.INFORMATION, "Security Check Queue Updated", data);
            _logger.LogInformation(logMessage);
        }
        /// <summary>
        /// Delete a Queue Object
        /// </summary>
        /// <param name="queueMessage"></param>
        /// <param name="_logger"></param>
        /// <returns></returns>
        public  async Task DeleteQueueAsync(TQueueMessage queueMessage, ILogger _logger)
        {
            await queueClient.DeleteMessageAsync(queueMessage.MessageId, queueMessage.PopReceipt);
            string logMessage =
                       ObjectConverter.CreateLogMessageObject(FunctionConstant.SECURITY_CHECK, LogConstant.INFORMATION, "Security Check Queue Deleted", null);
            _logger.LogInformation(logMessage);
        }
        /// <summary>
        /// Add to queue
        /// </summary>
        /// <param name="queueData"></param>
        /// <param name="_logger"></param>
        /// <returns></returns>
        public  async Task AddQueueAsync(QueueData queueData, ILogger _logger)
        {
            QueueClient queueClientRequest = new QueueClient(Environment.GetEnvironmentVariable("SecurityCheckStorageConnectionString"), Environment.GetEnvironmentVariable("SecurityCheckRequestQueue"));
            var data = JsonConvert.SerializeObject(queueData);
            await queueClientRequest.SendMessageAsync(data);
            string logMessage =
                       ObjectConverter.CreateLogMessageObject(FunctionConstant.SECURITY_CHECK, LogConstant.INFORMATION, "Security Check Queue Added", queueData);
            _logger.LogInformation(logMessage);
        }
    }
}