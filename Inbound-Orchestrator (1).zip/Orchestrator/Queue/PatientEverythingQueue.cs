using System;
using System.Net;
using System.Threading.Tasks;
using Azure;
using Azure.Storage.Queues;
using Azure.Storage.Queues.Models;
using MemberMatch;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Orchestrator.API;
using Orchestrator.Constants;
using Orchestrator.Model;
using Orchestrator.Util;

namespace Orchestrator.Queue
{
    /// <summary>
    /// This class is used to poll patient everything queue and do necessary CRUD operations
    /// </summary>

    public class PatientEverythingQueue
    {
        private  QueueClient queueClient = new QueueClient(Environment.GetEnvironmentVariable("PatientEverythingStorageConnectionString"), Environment.GetEnvironmentVariable("PatientEverythingResponseQueue"));

        /// <summary>
        /// Read a Queue Object
        /// </summary>
        /// <param name="_logger"></param>
        /// <returns></returns>
        public async Task ReadAsync(ILogger _logger)
        {

            QueueMessage queueMsg = await queueClient.ReceiveMessageAsync();
            TQueueMessage queueMessage = new TQueueMessage();
            if (queueMsg != null)
            {
                queueMessage.MessageId = queueMsg.MessageId;
                queueMessage.PopReceipt = queueMsg.PopReceipt;
                var data = JsonConvert.DeserializeObject<QueueData>(queueMsg.Body.ToString());
                if (data.Status.ToString().Equals(StatusConstant.PROCESS_DONE))
                {
                    string logMessage =
                      ObjectConverter.CreateLogMessageObject("PatitentEverythingQueue", LogConstant.INFORMATION, "Process Done", data);
                    _logger.LogInformation(logMessage);
                    // Business Logic
                    ObjectConverter objectConverter = new ObjectConverter();
                    // create update payload for metadata api
                    UpdateProcessMetadata updateProcessMetadata =
                        objectConverter.ProcessMetadataUpdate(
                            FunctionConstant.SECURITY_CHECK, StatusConstant.IN_PROCESS, data.MessageDescription, data.PeFhirId, data.DocumentRefId, data.FileName);
                    data.Status = StatusConstant.NOT_STARTED;
                    data.Stage = FunctionConstant.SECURITY_CHECK;
                    // call the update metadata api
                    OkResponse response = await MetadataApi.PutProcessMetadata(updateProcessMetadata, data.CfRequestId, _logger);
                    if (response.Code.Equals("OK"))
                    {
                        // check if ok // not implemented
                        SecurityCheckQueue securityCheckQueue = new SecurityCheckQueue();
                        await securityCheckQueue.AddQueueAsync(data, _logger);
                    }
                    else
                    {
                        await Utils.MetadataApiFailAsync("PatitentEverythingQueue", data, _logger);
                    }
                }
                else if (data.Status.ToString().Equals(StatusConstant.PROCESS_FAILED))
                {
                    await Utils.ProcessFailedAsync("PatitentEverythingQueue", data, FunctionConstant.PATIENT_EVERYTHING, _logger);
                }
                else if (data.Status.ToString().Equals(StatusConstant.TERMINATED))
                {
                    await Utils.ProcessTerminatedAsync("PatitentEverythingQueue", data, FunctionConstant.PATIENT_EVERYTHING, _logger);
                }
                await DeleteQueueAsync(queueMessage, _logger);
            }

        }
        /// <summary>
        /// Get queue client object
        /// </summary>
        /// <returns></returns>
        public  QueueClient GetQueueClient()
        {
              return queueClient;
        }
        /// <summary>
        /// Update a Queue Object
        /// </summary>
        /// <param name="queueMessage"></param>
        /// <param name="data"></param>
        /// <param name="_logger"></param>
        /// <returns></returns>
        public async Task UpdateQueueAsync(TQueueMessage queueMessage, QueueData data, ILogger _logger)
        {          

            var uData = JsonConvert.SerializeObject(data);
            Response<UpdateReceipt> response = await queueClient.UpdateMessageAsync(queueMessage.MessageId,
                        queueMessage.PopReceipt, uData, new TimeSpan(0, 0, 0));
            queueMessage.PopReceipt = response.Value.PopReceipt;
            string logMessage =
                         ObjectConverter.CreateLogMessageObject(FunctionConstant.PATIENT_EVERYTHING, LogConstant.INFORMATION, "Patitent Everything Queue Updated", data);
            _logger.LogInformation(logMessage);
        }
        /// <summary>
        /// Delete a Queue Object
        /// </summary>
        /// <param name="queueMessage"></param>
        /// <param name="_logger"></param>
        /// <returns></returns>
        public  async Task DeleteQueueAsync(TQueueMessage queueMessage, ILogger _logger)
        {
            await queueClient.DeleteMessageAsync(queueMessage.MessageId, queueMessage.PopReceipt);
            string logMessage =
                        ObjectConverter.CreateLogMessageObject(FunctionConstant.PATIENT_EVERYTHING, LogConstant.INFORMATION, "Patitent Everything Queue Deleted", null);
            _logger.LogInformation(logMessage);
        }
        /// <summary>
        /// Add to queue
        /// </summary>
        /// <param name="queueData"></param>
        /// <param name="_logger"></param>
        /// <returns></returns>
        public  async Task AddQueueAsync(QueueData queueData, ILogger _logger)
        {

            QueueClient queueClientRequest = new QueueClient(Environment.GetEnvironmentVariable("PatientEverythingStorageConnectionString"), Environment.GetEnvironmentVariable("PatientEverythingRequestQueue"));
            var data = JsonConvert.SerializeObject(queueData);
            await queueClientRequest.SendMessageAsync(data);
            string logMessage =
                        ObjectConverter.CreateLogMessageObject(FunctionConstant.PATIENT_EVERYTHING, LogConstant.INFORMATION, "Patitent Everything Queue Added", queueData);
            _logger.LogInformation(logMessage);
        }
    }
}