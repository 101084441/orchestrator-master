﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Orchestrator.Constants
{
    class FunctionConstant
    {
        public const string MEMBER_RESOLUTION = "Member Resolution";
        public const string PATIENT_EVERYTHING = "Patient Everything";
        public const string SECURITY_CHECK = "Security Check";
        public const string DOCUMENT_REFERENCE = "Document Reference";
        public const string INBOUND_AUTOMATION = "Inbound Automation";
        public const string ORCHESTRATOR = "Orchestrator";
    }
}
