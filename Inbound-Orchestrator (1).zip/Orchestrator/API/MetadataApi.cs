﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Orchestrator.Model;
using System.Net.Http;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net;
using Orchestrator.Util;
using Orchestrator.Constants;

namespace Orchestrator.API
{
    /// <summary>
    /// This class is responsible for updating the process metadata API
    /// </summary>
    class MetadataApi
    {
        /// <summary>
        /// This method does a post call to process metadata API
        /// </summary>
        /// <param name="createProcessMetadata"></param>
        /// <param name="_log"></param>
        /// <returns></returns>
        public static async Task<OkResponse> PostProcessMetadata(CreateProcessMetadata createProcessMetadata, ILogger _log)
        {
            //_log.LogInformation(DateTime.Now + "Entering into PostProcessMetadata method.");
            QueueData queueData = new QueueData();
            queueData.CfLob = createProcessMetadata.CfLob;
            queueData.CfMemberLifeId = createProcessMetadata.CfMemberLifeId;
            queueData.CfRequestId = createProcessMetadata.CfRequestId;
            queueData.OtherPayerId = createProcessMetadata.OtherPayerId;
            queueData.Status = createProcessMetadata.Status;
            string logMessage = ObjectConverter.CreateLogMessageObject("PostProcessMetadata", LogConstant.INFORMATION, "Creating new request in process metadata.", queueData);
            _log.LogInformation(logMessage);
            using (var client = new HttpClient())
            {
                // JsonConvert.SerializeObject(jsonObj, Formatting.Indented);
                var content = new StringContent(createProcessMetadata.ToJson(), Encoding.UTF8, "application/json");
                var response = await client.PostAsync(Environment.GetEnvironmentVariable("UrlProcessMetadata"), content);
                if (response.StatusCode.Equals(HttpStatusCode.OK))
                {
                    var jsonString = response.Content.ReadAsStringAsync();
                    OkResponse okResponse = JsonConvert.DeserializeObject<OkResponse>(jsonString.Result);
                    okResponse.Code = response.StatusCode.ToString();
                    return okResponse;
                }
                else
                {
                    try
                    {
                        var jsonString = response.Content.ReadAsStringAsync();
                        ErrorResponse errorResponse = JsonConvert.DeserializeObject<ErrorResponse>(jsonString.Result);
                          logMessage = 
                            ObjectConverter.CreateLogMessageObject("PostProcessMetadata", LogConstant.ERROR,
                            "Process Metadata Post api has thrown exception: " + errorResponse.issue[0].Diagnostics, queueData);
                        _log.LogError(logMessage);
                       
                        OkResponse okResponse = new OkResponse();
                        okResponse.Code = response.StatusCode.ToString();
                        okResponse.Response = errorResponse.issue[0].Diagnostics;
                        return okResponse;
                    }catch(Exception e)
                    {
                         logMessage =
                           ObjectConverter.CreateLogMessageObject("PostProcessMetadata", LogConstant.ERROR,
                           "Process Metadata Post api has thrown exception: " + e.Message, queueData);
                        _log.LogError(logMessage);

                        OkResponse okResponse = new OkResponse();
                        okResponse.Code = response.StatusCode.ToString();
                        var jsonString =await response.Content.ReadAsStringAsync();
                        okResponse.Response = jsonString;
                        return okResponse;
                    }
                }
            }
        }

        /// <summary>
        /// This method gets data from process metadata API
        /// </summary>
        /// <param name="field"></param>
        /// <param name="data"></param>
        /// <param name="_log"></param>
        /// <returns></returns>
        public static async Task<List<ProcessMetadata>> GetByProcessMetadata(String field, String data, ILogger _log)
        {
           // _log.LogInformation(DateTime.Now + "Entering into PostProcessMetadata method.");
            using (var client = new HttpClient())
            {              
                
                var url = Environment.GetEnvironmentVariable("UrlProcessMetadata") + "?"+field+"="+data ;
                var response = await client.GetAsync(url);
                try { 
                    var jsonString = response.Content.ReadAsStringAsync();
                    List<ProcessMetadata> processMetadatas = JsonConvert.DeserializeObject<List<ProcessMetadata>>(jsonString.Result);
                    return processMetadatas;
                }
                catch(Exception e)
                {                   
                    var jsonString = response.Content.ReadAsStringAsync();
                    ErrorResponse errorResponse = JsonConvert.DeserializeObject<ErrorResponse>(jsonString.Result);
                    _log.LogError(DateTime.Now + " " + errorResponse.issue[0].Diagnostics);
                    //return errorResponse.issue[0].Diagnostics;
                    throw e;
                }
               
            }
        }

        /// <summary>
        /// This method updates the process metadata API with some updated values
        /// </summary>
        /// <param name="updateProcessMetadata"></param>
        /// <param name="cfRequestId"></param>
        /// <param name="_log"></param>
        /// <returns></returns>
        public static async Task<OkResponse> PutProcessMetadata(UpdateProcessMetadata updateProcessMetadata, string cfRequestId, ILogger _log)
        {
           
            using (var client = new HttpClient())
            {
                // JsonConvert.SerializeObject(jsonObj, Formatting.Indented);
                var content = new StringContent(updateProcessMetadata.ToJson(), Encoding.UTF8, "application/json");
                var response = await client.PutAsync(Environment.GetEnvironmentVariable("UrlProcessMetadata") + "/" + cfRequestId, content);
                if (response.StatusCode.Equals(HttpStatusCode.OK))
                {
                    var jsonString = response.Content.ReadAsStringAsync();
                    OkResponse okResponse = JsonConvert.DeserializeObject<OkResponse>(jsonString.Result);
                    okResponse.Code = response.StatusCode.ToString();
                    return okResponse;
                }
                else
                {
                    try
                    {
                        var jsonString = response.Content.ReadAsStringAsync();
                        ErrorResponse errorResponse = JsonConvert.DeserializeObject<ErrorResponse>(jsonString.Result);
                        _log.LogError(DateTime.Now + " " + errorResponse.issue[0].Diagnostics);
                        OkResponse okResponse = new OkResponse();
                        okResponse.Code = response.StatusCode.ToString();
                        okResponse.Response = errorResponse.issue[0].Diagnostics;
                        return okResponse;
                    }
                    catch (Exception e)
                    {
                        _log.LogError(DateTime.Now + " " + response.StatusCode.ToString());
                        OkResponse okResponse = new OkResponse();
                        okResponse.Code = response.StatusCode.ToString();
                        var jsonString = await response.Content.ReadAsStringAsync();
                        okResponse.Response = jsonString;
                        return okResponse;
                    }
                }
            }
        }
    }
}