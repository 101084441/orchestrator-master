﻿using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Orchestrator.Constants;
using Orchestrator.Model;
using Orchestrator.Util;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace Orchestrator.API
{
    /// <summary>
    /// This class is responsible for doing API calls to and from CF
    /// </summary>
    class CfMemberRequestApi
    {
        /// <summary>
        /// This method updates CF member request API with some updated values
        /// </summary>
        /// <param name="updatePatientDataTransferRequest"></param>
        /// <param name="cfRequestId"></param>
        /// <param name="queueData"></param>
        /// <param name="_log"></param>
        /// <returns></returns>
        public static async Task<OkResponse> PutCfMemberRequestApi(UpdatePatientDataTransferRequest updatePatientDataTransferRequest, string cfRequestId,QueueData queueData, ILogger _log)
        {
           
            string token =await TokenGenerator.GetAccessTokenAsync(_log);
            if (updatePatientDataTransferRequest.RequestStatus != StatusConstant.TERMINATED)
            {
                PatientDataTransferResponse patientDataTransferResponse = await CfMemberRequestApi.GetByIdCfMemberRequestApi(_log, token,cfRequestId);
                string retryCount = patientDataTransferResponse.PatientDataTransferList[0].AdditionalAttributes.Retrycount;
                updatePatientDataTransferRequest.RetryCount = Convert.ToInt32(updatePatientDataTransferRequest.RetryCount) > Convert.ToInt32(retryCount) ? updatePatientDataTransferRequest.RetryCount : retryCount;
            }
            if (token != null)
            {
                string logMessage = ObjectConverter.CreateLogMessageObject("PutCfMemberRequestApi", LogConstant.STARTED, "Entering into PutCfMemberRequestApi method." ,null);
                _log.LogInformation(logMessage);
                // _log.LogInformation(DateTime.Now + "Entering into PutCfMemberRequestApi method.");
                using (var client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                    var content = new StringContent(updatePatientDataTransferRequest.ToJson(), Encoding.UTF8, "application/json");
                    var response = await client.PutAsync(Environment.GetEnvironmentVariable("UrlCfMemberRequestPut"), content);
                    if (response.StatusCode.Equals(HttpStatusCode.OK))
                    {
                        var jsonString = response.Content.ReadAsStringAsync();
                        ResponseContext responseContext = JsonConvert.DeserializeObject<ResponseContext>(jsonString.Result);
                        OkResponse okResponse = new OkResponse();
                        okResponse.Code = response.StatusCode.ToString();
                        okResponse.Response = responseContext.Success.ToString();
                        return okResponse;
                    }
                    else
                    {
                        var jsonString = response.Content.ReadAsStringAsync();
                        CfErrorResponse errorResponse = JsonConvert.DeserializeObject<CfErrorResponse>(jsonString.Result);
                        logMessage = ObjectConverter.CreateLogMessageObject("PutCfMemberRequestApi", LogConstant.ERROR, "CF Member Request update api has thrown exception: "+errorResponse.CfError.ErrorDetails[0].Error.Message,queueData );
                        _log.LogError(logMessage);
                        OkResponse okResponse = new OkResponse();
                        okResponse.Code = response.StatusCode.ToString();
                        okResponse.Response = errorResponse.CfError.ErrorDetails[0].Error.Message; ;
                        return okResponse;
                    }
                }
            }
            else
                return null;
        }

        /// <summary>
        /// This method gets member requests from CF API
        /// </summary>
        /// <param name="_log"></param>
        /// <param name="token"></param>
        /// <returns></returns>
        public static async Task<PatientDataTransferResponse> GetByCfMemberRequestApi(ILogger _log, string token)
        {
            // ObjectConverter objectConverter = new ObjectConverter();
            string logMessage = ObjectConverter.CreateLogMessageObject("GetByCfMemberRequestApi", LogConstant.INFORMATION, "Fetching new requests.", null);
            _log.LogInformation(logMessage);
           
            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                var url = Environment.GetEnvironmentVariable("UrlCfMemberRequestGet");
                var response = await client.GetAsync(url);
                if (response.StatusCode.Equals(HttpStatusCode.OK))
                {
                    var jsonString = response.Content.ReadAsStringAsync();
                    PatientDataTransferResponse patientDataTransferResponse = JsonConvert.DeserializeObject<PatientDataTransferResponse>(jsonString.Result);
                    return patientDataTransferResponse;
                }
                else
                {
                    var jsonString = response.Content.ReadAsStringAsync();
                    CfErrorResponse errorResponse = JsonConvert.DeserializeObject<CfErrorResponse>(jsonString.Result);
                    logMessage = ObjectConverter.CreateLogMessageObject("PutCfMemberRequestApi", LogConstant.ERROR, errorResponse.CfError.ErrorDetails[0].Error.Message ,null);
                    _log.LogError(logMessage);
                   // return errorResponse.CfError.ErrorDetails[0].Error.Message;
                    return null;
                }

            }
        }
        public static async Task<PatientDataTransferResponse> GetByIdCfMemberRequestApi(ILogger _log, string token,string id)
        {
            // ObjectConverter objectConverter = new ObjectConverter();
            string logMessage = ObjectConverter.CreateLogMessageObject("GetByIdCfMemberRequestApi", LogConstant.INFORMATION, "Get by cf request api ID: "+id, null);
            _log.LogInformation(logMessage);

            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                var url = Environment.GetEnvironmentVariable("UrlCfMemberRequestPut") + "?trackingIdentifier=" +id;
                var response = await client.GetAsync(url);
                if (response.StatusCode.Equals(HttpStatusCode.OK))
                {
                    var jsonString = response.Content.ReadAsStringAsync();
                    PatientDataTransferResponse patientDataTransferResponse = JsonConvert.DeserializeObject<PatientDataTransferResponse>(jsonString.Result);
                    return patientDataTransferResponse;
                }
                else
                {
                    var jsonString = response.Content.ReadAsStringAsync();
                    CfErrorResponse errorResponse = JsonConvert.DeserializeObject<CfErrorResponse>(jsonString.Result);
                    logMessage = ObjectConverter.CreateLogMessageObject("PutCfMemberRequestApi", LogConstant.ERROR, errorResponse.CfError.ErrorDetails[0].Error.Message, null);
                    _log.LogError(logMessage);
                    // return errorResponse.CfError.ErrorDetails[0].Error.Message;
                    return null;
                }

            }
        }
    }
}
