﻿using Microsoft.Extensions.Logging;
using Orchestrator.API;
using Orchestrator.Constants;
using Orchestrator.Model;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Orchestrator.Util
{
    class Utils
    {
        public static async Task MetadataApiFailAsync(string className, QueueData data, ILogger _logger) {
            string logMessage =
                       ObjectConverter.CreateLogMessageObject(className, LogConstant.FAILED, "Process Failed due to process metadata", data);
            _logger.LogError(logMessage);
            string status = Convert.ToInt32(data.RetryCount) == Convert.ToInt32(Environment.GetEnvironmentVariable("MaxRetryCount")) ? StatusConstant.TERMINATED : StatusConstant.IN_PROCESS;
            ObjectConverter objectConverter = new ObjectConverter();
            UpdateProcessMetadata updateProcessMetadata = objectConverter.ProcessMetadataUpdate(data.Stage, status == StatusConstant.TERMINATED ? StatusConstant.TERMINATED : data.Status, data.MessageDescription, data.PeFhirId, data.DocumentRefId, data.FileName);
            OkResponse response = await MetadataApi.PutProcessMetadata(updateProcessMetadata, data.CfRequestId, _logger);
            UpdatePatientDataTransferRequest updatePatientDataTransferRequest = objectConverter.UpdatePatientDataTransferRequest(FunctionConstant.INBOUND_AUTOMATION, status, "Process Metadata API failed", data.RetryCount, data.CfRequestId);
            await CfMemberRequestApi.PutCfMemberRequestApi(updatePatientDataTransferRequest, data.CfRequestId, data, _logger);
        }
        public static async Task ProcessFailedAsync(string className, QueueData data, string function,ILogger _logger)
        {
            string logMessage =
                       ObjectConverter.CreateLogMessageObject(className, LogConstant.FAILED, "Process Failed. Reason: "+data.MessageDescription, data);
            _logger.LogError(logMessage);
            string status = Convert.ToInt32(data.RetryCount) == Convert.ToInt32(Environment.GetEnvironmentVariable("MaxRetryCount")) ? StatusConstant.TERMINATED : StatusConstant.IN_PROCESS;
            ObjectConverter objectConverter = new ObjectConverter();
            UpdateProcessMetadata updateProcessMetadata = objectConverter.ProcessMetadataUpdate(data.Stage, status==StatusConstant.TERMINATED?StatusConstant.TERMINATED: data.Status, data.MessageDescription, data.PeFhirId, data.DocumentRefId, data.FileName);
            OkResponse response = await MetadataApi.PutProcessMetadata(updateProcessMetadata, data.CfRequestId, _logger);
            UpdatePatientDataTransferRequest updatePatientDataTransferRequest = objectConverter.UpdatePatientDataTransferRequest(FunctionConstant.INBOUND_AUTOMATION, status, data.MessageDescription, data.RetryCount, data.CfRequestId);
            await CfMemberRequestApi.PutCfMemberRequestApi(updatePatientDataTransferRequest, data.CfRequestId, data, _logger);
        }
        public static async Task ProcessTerminatedAsync(string className, QueueData data, string function, ILogger _logger)
        {
            string logMessage =
                       ObjectConverter.CreateLogMessageObject(className, LogConstant.FAILED, "Process Terminated. Reason: " + data.MessageDescription, data);
            _logger.LogError(logMessage);
            ObjectConverter objectConverter = new ObjectConverter();
            UpdateProcessMetadata updateProcessMetadata = objectConverter.ProcessMetadataUpdate(data.Stage, data.Status, data.MessageDescription, data.PeFhirId, data.DocumentRefId, data.FileName);
            OkResponse response = await MetadataApi.PutProcessMetadata(updateProcessMetadata, data.CfRequestId, _logger);
            UpdatePatientDataTransferRequest updatePatientDataTransferRequest = objectConverter.UpdatePatientDataTransferRequest(FunctionConstant.INBOUND_AUTOMATION, StatusConstant.TERMINATED, data.MessageDescription, data.RetryCount, data.CfRequestId);
            await CfMemberRequestApi.PutCfMemberRequestApi(updatePatientDataTransferRequest, data.CfRequestId, data, _logger);
        }
        public static async Task NullCheckFailAsync(string className, QueueData data, StringBuilder nullFields,PatientDataTransfer patientDataTransfer, ILogger _logger)
        {
            string logMessage =
                       ObjectConverter.CreateLogMessageObject(className, LogConstant.FAILED, "Process terminated due to null values: " + nullFields, data);
            _logger.LogError(logMessage);
            ObjectConverter objectConverter = new ObjectConverter();
           
            UpdatePatientDataTransferRequest updatePatientDataTransferRequest = objectConverter.UpdatePatientDataTransferRequest
                       (patientDataTransfer.UpdatedBy, StatusConstant.TERMINATED,
                       "Process terminated due to null values: " + nullFields, patientDataTransfer.AdditionalAttributes.Retrycount,
                       patientDataTransfer.TrackingIdentifier);
            await CfMemberRequestApi.PutCfMemberRequestApi(updatePatientDataTransferRequest, patientDataTransfer.TrackingIdentifier, data, _logger);
        }
        public static async Task MetadataPostApiFailAsync(string className, QueueData data,OkResponse okResponse, ILogger _logger)
        {
            string logMessage =
                       ObjectConverter.CreateLogMessageObject(className, LogConstant.FAILED, "Process Failed due to process metadata. Error: "+okResponse.Response, data);
            _logger.LogError(logMessage);
            string status = Convert.ToInt32(data.RetryCount) == Convert.ToInt32(Environment.GetEnvironmentVariable("MaxRetryCount")) ? StatusConstant.TERMINATED : StatusConstant.IN_PROCESS;
            ObjectConverter objectConverter = new ObjectConverter();
            UpdatePatientDataTransferRequest updatePatientDataTransferRequest = objectConverter.UpdatePatientDataTransferRequest(FunctionConstant.INBOUND_AUTOMATION, status, "Process Metadata API failed. Error: "+okResponse.Response, data.RetryCount, data.CfRequestId);
            await CfMemberRequestApi.PutCfMemberRequestApi(updatePatientDataTransferRequest, data.CfRequestId, data, _logger);
        }
        public static int GetTaskCount(int reqCount)
        {
            int maxReqsCount = Convert.ToInt32(Environment.GetEnvironmentVariable("MaxProcessCount"));
            int count = reqCount <= maxReqsCount ? reqCount : maxReqsCount;
            return count;
        }
    
    }
}
