﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using Microsoft.Extensions.Logging;
using Orchestrator.API;
using Orchestrator.Constants;
using Orchestrator.Model;

namespace Orchestrator.Util
{
    /// <summary>
    /// This class is used for converting objects , checking for nulls and creating log structure
    /// </summary>
    class ObjectConverter
    {

        /// <summary>
        /// This method is used to converting PatientDataTransfer object to ProcessMetadata
        /// </summary>
        /// <param name="patientDataTransfer"></param>
        /// <returns></returns>
        public CreateProcessMetadata PatientDataTansferToProcessMetadata(PatientDataTransfer patientDataTransfer)
        {
            CreateProcessMetadata createProcessMetadata = new CreateProcessMetadata
            {
                CfRequestId = patientDataTransfer.TrackingIdentifier,
                CfLob = patientDataTransfer.Patient.Lob,
                CfMemberLifeId = patientDataTransfer.Patient.MemberLifeId,
                OtherPayerId = patientDataTransfer.Payer.PayerRegistrationId,
                OtherPayerName = patientDataTransfer.Payer.PayerName,
                FhirId = patientDataTransfer.Patient.FhirId,
                OldCoverageId = patientDataTransfer.OldCoverage.EnrolleeId,
                Stage = FunctionConstant.MEMBER_RESOLUTION,
                Status = StatusConstant.IN_PROCESS,
                MessageDescription = ""
            };
            return createProcessMetadata;
        }

        /// <summary>
        /// This method is used to create a update process metadata object from given data
        /// </summary>
        /// <param name="stage"></param>
        /// <param name="status"></param>
        /// <param name="msgDesc"></param>
        /// <param name="peFhirId"></param>
        /// <param name="docRefId"></param>
        /// <param name="fileName"></param>
        /// <returns></returns>
        public UpdateProcessMetadata ProcessMetadataUpdate(string stage, string status, string msgDesc, string peFhirId, string docRefId, string fileName)
        {
            UpdateProcessMetadata updateProcessMetadata = new UpdateProcessMetadata
            {
                Stage = stage,
                Status = status,
                MessageDescription = msgDesc,
                DocRefFhirId = docRefId,
                PeFhirId = peFhirId,
                FileName = fileName
            };
            return updateProcessMetadata;
        }

        /// <summary>
        /// This method is used to create  a queueData object from PatientDataTransfer object
        /// </summary>
        /// <param name="patientDataTransfer"></param>
        /// <param name="stage"></param>
        /// <returns></returns>
        public QueueData PatientDataTansferToQueueData(PatientDataTransfer patientDataTransfer, string stage)
        {
            QueueData queueData = new QueueData
            {
                CfRequestId = patientDataTransfer.TrackingIdentifier,
                CfLob = patientDataTransfer.Patient.Lob,
                CfMemberLifeId = patientDataTransfer.Patient.MemberLifeId,
                OtherPayerId = patientDataTransfer.Payer.PayerRegistrationId,
                OtherPayerName = patientDataTransfer.Payer.PayerName,
                FhirId = patientDataTransfer.Patient.FhirId,
                MemberFirstName = patientDataTransfer.OldCoverage.EnrolleeFirstName,
                MemberMiddleName = patientDataTransfer.OldCoverage.EnrolleeMiddleName,
                MemberLastName = patientDataTransfer.OldCoverage.EnrolleeLastName,
                MemberDOB = patientDataTransfer.Patient.MemberDob,
                Gender = patientDataTransfer.Patient.Gender==null?null:patientDataTransfer.Patient.Gender.ToLower(),
                OldCoverageId = patientDataTransfer.OldCoverage.EnrolleeId,
                OldCoverageStatus = patientDataTransfer.OldCoverage.Status==null?null: patientDataTransfer.OldCoverage.Status.ToLower(),
                OldCoverageName = patientDataTransfer.OldCoverage.CoverageName,
                OldCoverageGroup = patientDataTransfer.OldCoverage.Group,
                Stage = stage,
                Status = StatusConstant.NOT_STARTED,
                MessageDescription = "",
                PeFhirId = null,
                DocumentRefId = null,
                RetryCount = patientDataTransfer.AdditionalAttributes.Retrycount
            };
            return queueData;
        }

        /// <summary>
        /// This method is used to create  a queueData object from PatientDataTransfer object and processmetadata object
        /// </summary>
        /// <param name="patientDataTransfer"></param>
        /// <param name="processMetadata"></param>
        /// <returns></returns>
        public QueueData ProcessMetadataToQueueData(PatientDataTransfer patientDataTransfer, ProcessMetadata processMetadata)
        {
            QueueData queueData = new QueueData
            {
                CfRequestId = processMetadata.CfRequestId,
                CfLob = processMetadata.CfLob,
                CfMemberLifeId = processMetadata.CfMemberLifeId,
                OtherPayerId = processMetadata.OtherPayerId,
                OtherPayerName = processMetadata.OtherPayerName,
                FhirId = processMetadata.FhirId,
                MemberFirstName = patientDataTransfer.Patient.MemberFirstName,
                MemberLastName = patientDataTransfer.Patient.MemberLastName,
                MemberDOB = patientDataTransfer.Patient.MemberDob,
                Gender = patientDataTransfer.Patient.Gender,
                OldCoverageId = processMetadata.OldCoverageId,
                OldCoverageStatus = patientDataTransfer.OldCoverage.Status,
                OldCoverageName = patientDataTransfer.OldCoverage.CoverageName,
                OldCoverageGroup = patientDataTransfer.OldCoverage.Group,
                Stage = processMetadata.Stage,
                Status = StatusConstant.NOT_STARTED,
                MessageDescription = "",
                PeFhirId = null,
                DocumentRefId = null,
                RetryCount = patientDataTransfer.AdditionalAttributes.Retrycount
            };
            return queueData;
        }

        /// <summary>
        /// This method is used to create UpdatePatientDataTransferRequest object from given data
        /// </summary>
        /// <param name="lastUpdatedBy"></param>
        /// <param name="requestStatus"></param>
        /// <param name="requestStatusDesc"></param>
        /// <param name="retryCount"></param>
        /// <param name="trackingIdentifier"></param>
        /// <returns></returns>
        public UpdatePatientDataTransferRequest UpdatePatientDataTransferRequest(string lastUpdatedBy, string requestStatus, string requestStatusDesc, string retryCount, string trackingIdentifier)
        {
            UpdatePatientDataTransferRequest updatePatientDataTransferRequest = new UpdatePatientDataTransferRequest
            {
                UpdatedBy = lastUpdatedBy,
                RequestStatus = requestStatus.ToString(),
                RequestStatusDesc = requestStatusDesc,
                RetryCount = retryCount,
                TrackingIdentifier = trackingIdentifier
            };

            return updatePatientDataTransferRequest;
        }

        /// <summary>
        /// This method is used to check null in CF member request api reponse
        /// </summary>
        /// <param name="patientDataTransfer"></param>
        /// <returns></returns>
        public CheckNull CheckForNullFromCFInputs(PatientDataTransfer patientDataTransfer)
        {
            CheckNull checkNull = new CheckNull
            {
                NullFields = new StringBuilder(),
                IsSuccess = false
            };
            int count = 0;
            checkNull.NullFields.Append("{");
            if (string.IsNullOrEmpty(patientDataTransfer.Patient.MemberLifeId))
            {
                checkNull.NullFields.Append("MemberLifeId,");
                count++;
            }
            else if (string.IsNullOrEmpty(patientDataTransfer.OldCoverage.EnrolleeFirstName))
            {                
                checkNull.NullFields.Append("MemberFirstName,");
                count++;
            }
           

            else if (string.IsNullOrEmpty(patientDataTransfer.Patient.Gender))
            {
                checkNull.NullFields.Append("Gender,");
                count++;
            }
            else if (string.IsNullOrEmpty(patientDataTransfer.Patient.MemberDob))
            {
                checkNull.NullFields.Append("MemberDob,");
                count++;
            }
            else if (string.IsNullOrEmpty(patientDataTransfer.Patient.Lob))
            {
                checkNull.NullFields.Append("Lob,");
                count++;
            }
            else if (string.IsNullOrEmpty(patientDataTransfer.Patient.FhirId))
            {
                checkNull.NullFields.Append("FhirId,");
                count++;
            }
            else if (string.IsNullOrEmpty(patientDataTransfer.Payer.PayerRegistrationId))
            {
                checkNull.NullFields.Append("PayerRegistrationId,");
                count++;
            }           
            else if (string.IsNullOrEmpty(patientDataTransfer.OldCoverage.Group))
            {
                checkNull.NullFields.Append("Group,");
                count++;
            }
            else if (string.IsNullOrEmpty(patientDataTransfer.OldCoverage.Status))
            {
                checkNull.NullFields.Append("Status,");
                count++;
            }
            checkNull.NullFields.Append("}");
            if (count > 0)
                checkNull.IsSuccess = false;
            else
                checkNull.IsSuccess = true;
            return checkNull;           

        }

        /// <summary>
        /// This method is used to update cf and metadata API
        /// </summary>
        /// <param name="data"></param>
        /// <param name="functionConstant"></param>
        /// <param name="statusConstant"></param>
        /// <param name="message"></param>
        /// <param name="_logger"></param>

        public async void UpdateMetdataandCF(QueueData data, string functionConstant, string statusConstant, string message, ILogger _logger)
        {
            ObjectConverter objectConverter = new ObjectConverter();
            // create update payload for metadata api
            UpdateProcessMetadata updateProcessMetadata =
                objectConverter.ProcessMetadataUpdate(
                   functionConstant, statusConstant, data.MessageDescription, data.PeFhirId, null, null);
            // call the update metadata api
            OkResponse response = await MetadataApi.PutProcessMetadata(updateProcessMetadata, data.CfRequestId, _logger);
            if (response.Code.Equals(HttpStatusCode.OK))
            {
                // business logic
                UpdatePatientDataTransferRequest updatePatientDataTransferRequest = objectConverter.UpdatePatientDataTransferRequest("", statusConstant, message, data.RetryCount, data.CfRequestId);
                // await CfMemberRequestApi.PutCfMemberRequestApi(updatePatientDataTransferRequest, data.CfRequestId, _logger);
                // await DeleteQueueAsync(queueMessage, _logger);
            }
            else
            {
                // business logic
                UpdatePatientDataTransferRequest updatePatientDataTransferRequest = objectConverter.UpdatePatientDataTransferRequest("", StatusConstant.PROCESS_RETRY, "Metadata API failed", data.RetryCount, data.CfRequestId);
                //  await CfMemberRequestApi.PutCfMemberRequestApi(updatePatientDataTransferRequest, data.CfRequestId, _logger);
                // await DeleteQueueAsync(queueMessage, _logger);
            }
        }

        /// <summary>
        /// This method is used to create a log message format
        /// </summary>
        /// <param name="method"></param>
        /// <param name="status"></param>
        /// <param name="description"></param>
        /// <param name="data"></param>
        /// <returns></returns>
        public static string CreateLogMessageObject(string method, string status, string description, QueueData data)
        {
            string log = "";

            if (data != null)
            {
                LogMessage logMessage = new LogMessage()
                {
                    Description = description,
                    Method = method,
                    Status = status,
                    Identity = new Identity
                    {
                        CfLob = data == null ? null : data.CfLob,
                        CfMemberLifeId = data == null ? null : data.CfMemberLifeId,
                        CfRequestId = data == null ? null : data.CfRequestId,
                        OtherPayerId = data == null ? null : data.OtherPayerId,
                        OtherPayerName = data == null ? null : data.OtherPayerName,
                        Status = data == null ? null : data.Status
                    }
                };
                log = logMessage.ToLogMessage();
                return log;
            }
            else
            {
                LogMessage logMessage = new LogMessage()
                {
                    Description = description,
                    Method = method,
                    Status = status,

                };
                log = logMessage.ToLogMessage();
                return log;
            }


        }      

    }
}
