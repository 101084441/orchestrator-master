﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Orchestrator.Util
{
    class CurrentProcessCount
    {
        private int currentProcessCount = 0;
        public int GetCurrentProcessCount()
        {
            return currentProcessCount;
        }
        public void SetCurrentProcessCount(int count) {
            currentProcessCount = currentProcessCount + count;
        }
        public void PopCurrentProcessCount() {
            currentProcessCount = currentProcessCount-1;
        }
    }
    
}
