﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MemberMatch
{
    public static class StatusConstant
    {
        public const string NOT_STARTED = "NotStarted";
        public const string IN_PROCESS = "InProcess";
        public const string PROCESS_FAILED = "ProcessFailed";
        public const string PROCESS_RETRY = "ProcessRetry";
        public const string PROCESS_DONE = "ProcessDone";
        public const string COMPLETED = "Completed";
        public const string TERMINATED = "Terminated";

    }
    public static class LogConstant
    {
        public const string STARTED = "STARTED";
        public const string INFORMATION = "INFORMATION";
        public const string FAILED = "FAILED";
        public const string SUCCESS = "SUCCESS";
        public const string ERROR = "ERROR";
    }
}
