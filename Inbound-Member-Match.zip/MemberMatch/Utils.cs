﻿using Azure;
using Azure.Storage.Blobs;
using Azure.Storage.Queues;
using Azure.Storage.Queues.Models;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace MemberMatch
{
    class Utils
    {
        /// <summary>
        /// This method is used to update the queue.
        /// </summary>
        /// <param name="queueClient"></param>
        /// <param name="queueMessage"></param>
        /// <param name="data"></param>
        /// <param name="_logger"></param>
        /// <param name="status"></param>
        /// <returns></returns>

        List<string> taskList = new List<string>();
        internal static async Task
            UpdateQueue(TQueueMessage queueMessage, Data data, string status, string msg, ILogger _logger)
        {
            //string logMessage = CreateLogMessageObject( "UpdateQueue", "Information", "Entering into UpdateQueue method.", data);
            //_logger.LogInformation(logMessage);
            QueueClient queueClient = new QueueClient(Environment.GetEnvironmentVariable("StorageConnectionString"), Environment.GetEnvironmentVariable("RequestQueueName"));
            try
            {
                data.Status = status;
                data.MessageDescription = msg == null ? data.MessageDescription : msg;
                var uData = JsonConvert.SerializeObject(data);
                //_logger.LogInformation("Updated Message: {data}", uData);
                Response<UpdateReceipt> response = await queueClient.UpdateMessageAsync(queueMessage.MessageId,
                            queueMessage.PopReceipt, uData, new TimeSpan(0, 0, 0));
                queueMessage.PopReceipt = response.Value.PopReceipt;

                string logMessage = CreateLogMessageObject( "UpdateQueue",LogConstant.SUCCESS, "Updated queue succesfully.", data);
                _logger.LogInformation(logMessage);
            }
            catch (Exception e)
            {
                string logMessage = CreateLogMessageObject( "UpdateQueue", LogConstant.ERROR, "Error updating queue." + e.Message.ToString(), data);
                _logger.LogError(logMessage);
            }
            //finally
            //{
            //    logMessage = CreateLogMessageObject( "UpdateQueue", "Information", "Exiting UpdateQueue method.", data);
            //    _logger.LogInformation(logMessage);
            //}

        }
        public static async Task<string> readBlobAsync()
        {
            var text = "";
            BlobContainerClient blobContainerClient = new BlobContainerClient("DefaultEndpointsProtocol=https;AccountName=stfhirloaderdev001;AccountKey=yj7mV0hB+F2vPYeEcQOG1SvXo0wm0UhDaXcNsonXb9MJmTERGfLQmcovyBWyc7Vtx3QO/aBLSPRosj5TB4j42g==;EndpointSuffix=core.windows.net", "member-resolution");

            // List all blobs in the container
            var blobs = blobContainerClient.GetBlobs();
            BlobClient blobClient = blobContainerClient.GetBlobClient("memberinput.json");
            if (await blobClient.ExistsAsync())
            {
                var response = await blobClient.DownloadAsync();

                using (StreamReader reader = new StreamReader(blobClient.OpenRead()))
                {
                    text = reader.ReadToEnd();
                }
            }
            return text;
        }

        public static async Task UpdateResponseQueueAndDeleteRequestQueue(TQueueMessage queueMessage, Data queueData, ILogger _logger)
        {
            //string logMessage = CreateLogMessageObject("UpdateResponseQueueAndDeleteRequestQueue", "Information", "Entering into UpdateQueue method.", queueData);
            //_logger.LogInformation(logMessage);
            QueueClient queueClient = new QueueClient(Environment.GetEnvironmentVariable("StorageConnectionString"), Environment.GetEnvironmentVariable("RequestQueueName"));
            try
            {
                var data = JsonConvert.SerializeObject(queueData);
                QueueClient queueClientResponse = new QueueClient(Environment.GetEnvironmentVariable("StorageConnectionString"), Environment.GetEnvironmentVariable("ResponseQueueName"));
                await queueClientResponse.SendMessageAsync(data);
                QueueClient queueClientRequest = new QueueClient(Environment.GetEnvironmentVariable("StorageConnectionString"), Environment.GetEnvironmentVariable("RequestQueueName"));
                await queueClientRequest.DeleteMessageAsync(queueMessage.MessageId, queueMessage.PopReceipt);

                string logMessage = CreateLogMessageObject("UpdateResponseQueueAndDeleteRequestQueue", LogConstant.SUCCESS, "Patient transfer object moved from request to response queue.", queueData);
                _logger.LogInformation(logMessage);
            }
            catch (Exception e)
            {
                string logMessage = CreateLogMessageObject( "UpdateResponseQueueAndDeleteRequestQueue", LogConstant.ERROR, "Error updating queue." + e.Message.ToString(), queueData);
                _logger.LogError(logMessage);
            }
            //finally
            //{
            //    logMessage = CreateLogMessageObject( "UpdateResponseQueueAndDeleteRequestQueue", "Information", "Exiting UpdateResponseQueueAndDeleteRequestQueue method.", queueData);
            //    _logger.LogInformation(logMessage);
            //}
        }

        public static string CreateLogMessageObject( string method, string status, string description, Data data)
        {
            string log = "";
            LogMessage logMessage = new LogMessage()
            {
                Description = description,
                Method = method,
                Status = status,
                Identity = new Identity
                {
                    CfLob = data==null?null:data.CfLob,
                    CfMemberLifeId = data == null ? null : data.CfMemberLifeId,
                    CfRequestId = data == null ? null : data.CfRequestId,
                    OtherPayerId = data == null ? null : data.OtherPayerId,
                    OtherPayerName = data == null ? null : data.OtherPayerName,
                    Status = data == null ? null : data.Status
                }
            };
            log = logMessage.ToLogMessage();
            return log;

        }
        public void AddTask(string task) {
            taskList.Add(task);
        }
        public void RemoveTask(string task)
        {
            taskList.Remove(task);
        }
        public bool IsInTaskList(string task)
        {
            return taskList.Contains(task);
        }
        public void ListTasks(ILogger logger)
        {
            logger.LogInformation("In Task List: "+string.Join(", ", taskList));
        }
    }

}
