﻿using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace MemberMatch
{
    /// <summary>
    /// This class is used to genrate token new or when expired
    /// </summary>
    class TokenGenerator
    {
        private static string _authString { get; set; }

        private static int _retryCount { get; set; }

        private static DateTime _expiredDateTimeUtc { get; set; }

        /// <summary>
        /// This method evaluates if the token is expired when it is accessed. If expired, 
        /// new token is automatically populated, and new token string returned  
        /// </summary>
        /// <param name="queueMessage"></param>
        /// <param name="queueData"></param>
        /// <param name="_log"></param>
        /// <returns></returns>

        public static async Task<string> GetAccessTokenAsync(TQueueMessage queueMessage, Data queueData, ILogger _log)
        {
            if (_expiredDateTimeUtc < DateTime.UtcNow)
            {
                _authString = await GetTokenAsync(queueMessage, queueData, _log);
            }
            return _authString;
        }
       
        /// <summary>
        /// This method generates a new token.
        /// </summary>
        /// <param name="_queueMessage"></param>
        /// <param name="_queueData"></param>
        /// <param name="_logger"></param>
        /// <returns></returns>
        private static async Task<string> GetTokenAsync(TQueueMessage _queueMessage, Data _queueData, ILogger _logger)
        {
            string token = null;
            string logMessage = Utils.CreateLogMessageObject("GetAccessTokenAsync", LogConstant.STARTED, "Fetching access token.", _queueData);
            _logger.LogInformation(logMessage);
            using (var client = new HttpClient())
            {
                var data = new[] {
                    new KeyValuePair<string, string>("client_id", Environment.GetEnvironmentVariable("ClientId")),
                    new KeyValuePair<string, string>("client_secret", Environment.GetEnvironmentVariable("ClientSecret")),
                    new KeyValuePair<string, string>("grant_type", "client_credentials")
                };

                var response = await client.PostAsync(Environment.GetEnvironmentVariable("URLOAuth"), new FormUrlEncodedContent(data));
                try
                {
                    response.EnsureSuccessStatusCode();
                    var jsonString = response.Content.ReadAsStringAsync();
                    var jsonObj = JObject.Parse(jsonString.Result);
                    token = jsonObj.GetValue("access_token").ToString();
                    var expiryMinutes = 0;
                    expiryMinutes = Convert.ToInt32(jsonObj.GetValue("expires_in")) / 60;
                    _expiredDateTimeUtc = DateTime.UtcNow.AddMinutes(expiryMinutes - 5);     // Set expiry field to to be valid till 5 minutes less than actual expiry time.
                    _retryCount = 0;
                    logMessage = Utils.CreateLogMessageObject("GetAccessTokenAsync", LogConstant.SUCCESS, "Access token received.", _queueData);
                    _logger.LogInformation(logMessage);
                    return token;
                }
                catch (Exception e)
                {
                    logMessage = Utils.CreateLogMessageObject("GetAccessTokenAsync", LogConstant.FAILED, "Failed to fetch access token. Error Detials: " + e.Message.ToString(), _queueData);
                    _logger.LogError(logMessage);
                    await Utils.UpdateQueue(_queueMessage, _queueData, StatusConstant.PROCESS_FAILED, "Failed to fetch access token. Error Detials: " + e.Message.ToString(), _logger);
                    await Utils.UpdateResponseQueueAndDeleteRequestQueue(_queueMessage, _queueData, _logger);
                    Utils utils = new Utils();
                    utils.RemoveTask(_queueMessage.MessageId);
                    return null;
                }
            }
        }
    }
}

