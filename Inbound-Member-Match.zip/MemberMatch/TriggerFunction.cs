using System;
using System.Threading.Tasks;
using Azure.Storage.Queues;
using Azure.Storage.Queues.Models;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace MemberMatch
{
    /// <summary>
    /// This class is responsible for triggering the ExecuteAsync function in every 10 seconds.
    /// </summary>
    public static class TriggerFunction
    {
        /// <summary>
        /// This method triggers in every 10 seconds
        /// </summary>
        /// <param name="myTimer"></param>
        /// <param name="log"></param>
        /// <returns></returns>
        [FunctionName("MemberResolution")]
        public static async Task RunAsync([TimerTrigger("%Timer%")] TimerInfo myTimer, ILogger log, ExecutionContext ec)
        {
            log.LogInformation($"C# Timer trigger function executed at: {DateTime.Now}");
            await ExecuteAsync(ec,log);
        }
        /// <summary>
        /// This method is used to check for queue messages and work upon them.
        /// </summary>
        /// <param name="_logger"></param>
        /// <returns></returns>
        private static async Task ExecuteAsync(ExecutionContext ec,ILogger _logger)
        {
            QueueClient queueClient = new QueueClient(Environment.GetEnvironmentVariable("StorageConnectionString"), Environment.GetEnvironmentVariable("RequestQueueName"));
            QueueMessage queueMsg = await queueClient.ReceiveMessageAsync();
            TQueueMessage queueMessage = new TQueueMessage();
            Utils utils = new Utils();
            string wwwRoot = ec.FunctionAppDirectory;
            
            if (queueMsg != null)
            {
                queueMessage.MessageId = queueMsg.MessageId;
                queueMessage.PopReceipt = queueMsg.PopReceipt;
                var data = JsonConvert.DeserializeObject<Data>(queueMsg.Body.ToString());
                _logger.LogInformation(DateTime.Now+" :New Mesasge Read from Member Resolution Request Queue: {data}", queueMsg.Body);
                if (data.Status.ToString().Equals(StatusConstant.NOT_STARTED))
                {
                    utils.AddTask(queueMessage.MessageId);
                    utils.ListTasks(_logger);
                    await Utils.UpdateQueue(queueMessage, data, StatusConstant.IN_PROCESS, null, _logger);
                   
                    string accessToken = await TokenGenerator.GetAccessTokenAsync(queueMessage,data,_logger);
                    //string accessToken = Environment.GetEnvironmentVariable("AccessToken");
                    if (accessToken != null)
                    {
                        string jsonPayLoad = await MemberMatch.InsertDetailsIntoJsonPayloadAsync(wwwRoot, queueMessage, data, _logger);
                        if (jsonPayLoad != null)
                        {
                            string systemValue = await MemberMatch.FetchUMBFromResponseAsync(jsonPayLoad, accessToken, queueMessage, data, _logger);
                            if (systemValue != null)
                            {
                                await MemberMatch.GetFhirIDAsync(accessToken, systemValue, queueMessage, data, _logger);

                            }
                        }

                    }

                }
                else if (data.Status.ToString().Equals(StatusConstant.IN_PROCESS)) {
                    utils.ListTasks(_logger);
                    if (!utils.IsInTaskList(queueMessage.MessageId))
                    {
                        string logMessage = Utils.CreateLogMessageObject("ExecuteAsync", LogConstant.INFORMATION, "Restarting Task.", data);
                        _logger.LogWarning(logMessage);
                        await Utils.UpdateQueue(queueMessage, data, StatusConstant.NOT_STARTED, "Restarting Task", _logger);
                    }
                }
            }
        }


    }
}

