﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MemberMatch
{
    public class Data
    {
        public string CfRequestId { get; set; }
        public string CfLob { get; set; }
        public string CfMemberLifeId { get; set; }
        public string FhirId { get; set; }
        public string OtherPayerId { get; set; }
        public string OtherPayerName { get; set; }
        public string MemberFirstName { get; set; }
        public string MemberMiddleName { get; set; }
        public string MemberLastName { get; set; }
        public string MemberDOB { get; set; }
        public string Gender { get; set; }
        public string OldCoverageId { get; set; }
        public string OldCoverageName { get; set; }
        public string OldCoverageGroup { get; set; }
        public string OldCoverageStatus { get; set; }
        public string Stage { get; set; }
        public string Status { get; set; }
        public string MessageDescription
        {
            get; set;
        } = null;
        public string PeFhirId { get; set; } = null;
        public string DocumentRefId { get; set; } = null;
        public string FileName { get; set; }
        public string RetryCount { get; set; }
    }
}
