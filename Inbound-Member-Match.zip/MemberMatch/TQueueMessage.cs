﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MemberMatch
{
    public class TQueueMessage
    {
        public string MessageId { get; set; }
        //
        // Summary:
        //     This value is required to delete the Message. If deletion fails using this popreceipt
        //     then the message has been dequeued by another client.
        public string PopReceipt { get; set; }
        //
        // Summary:
        //     The content of the Message.
       
        public string MessageText { get; set; }
        //
        // Summary:
        //     The content of the Message.
        public BinaryData Body { get; set; }
        //
        // Summary:
        //     The time that the message will again become visible in the Queue.
        public DateTimeOffset? NextVisibleOn { get; }
        //
        // Summary:
        //     The time the Message was inserted into the Queue.
        public DateTimeOffset? InsertedOn { get; }
        //
        // Summary:
        //     The time that the Message will expire and be automatically deleted.
        public DateTimeOffset? ExpiresOn { get; }
        //
        // Summary:
        //     The number of times the message has been dequeued.
        public long DequeueCount { get; set; }



    }
}
