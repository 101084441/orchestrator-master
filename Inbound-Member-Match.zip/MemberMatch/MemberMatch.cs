using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Collections.Generic;
using System.Net.Http.Headers;
using Azure.Storage.Queues.Models;

namespace MemberMatch
{
    /// <summary>
    /// This class does the member match in three steps-
    /// 1. Create $member-match payload json
    /// 2. Do $member-match api call to CF apigee API and fetch system and UMB
    /// 3. Do /patient? identifier = UMB and get FHIR ID
    /// </summary>
    public static class MemberMatch
    {
        /// <summary>
        /// This method creates a member match payload json which will be used in future api calls
        /// </summary>
        /// <param name="queueMessage"></param>
        /// <param name="queueData"></param>
        /// <param name="_log"></param>
        /// <returns></returns>
        public static async Task<string>
            InsertDetailsIntoJsonPayloadAsync(String wwwRoot,TQueueMessage queueMessage, Data queueData, ILogger _log)
        {
            string logMessage = Utils.CreateLogMessageObject( "InsertDetailsIntoJsonPayloadAsync", LogConstant.STARTED, "Generating member match payload.", queueData);
            _log.LogInformation(logMessage);
            string family = queueData.MemberLastName;
            JArray given = new JArray {queueData.MemberFirstName, queueData.MemberMiddleName };
            string gender = queueData.Gender;
            string group = queueData.OldCoverageGroup;
            string planStatus = queueData.OldCoverageStatus;
            string DOB = queueData.MemberDOB;
            string output = null;
            try
            {
                //_log.LogInformation("Root Path:- " + wwwRoot);
                string jsonFile = wwwRoot + @"\memberinput.json";
                _log.LogInformation("File Path:- " + jsonFile);
                var json = File.ReadAllText(jsonFile);
               // var json = await Utils.readBlobAsync();
                var jsonObj = JObject.Parse(json);
                var parameterArray = jsonObj.GetValue("parameter") as JArray;

                //To update the input payload with the method paramters.
                foreach (var name in parameterArray.Select(obj => obj["resource"]))
                {
                    if (name["name"] != null && name["name"].ToString() != "")
                    {
                        name["name"][0]["family"] = !string.IsNullOrEmpty(family) ? family : "";
                        name["name"][0]["given"] = given.Count != 0 ? given : null;
                    }
                    if (name["class"] != null && name["class"].ToString() != "")
                    {
                        name["class"][0]["value"] = !string.IsNullOrEmpty(group) ? group : "";
                    }
                    if (name["gender"] != null && name["gender"].ToString() != "")
                    {
                        name["gender"] = !string.IsNullOrEmpty(gender) ? gender : "";
                    }
                    if (name["birthDate"] != null && name["birthDate"].ToString() != "")
                    {
                        name["birthDate"] = !string.IsNullOrEmpty(DOB) ? DOB : "";
                    }
                    if (name["status"] != null && name["status"].ToString() != "")
                    {
                        name["status"] = !string.IsNullOrEmpty(planStatus) ? planStatus : "";
                    }
                }
                jsonObj["parameter"] = parameterArray;
                output = JsonConvert.SerializeObject(jsonObj, Formatting.Indented);
                // File.WriteAllText(jsonFile, output);
                 logMessage = Utils.CreateLogMessageObject( "InsertDetailsIntoJsonPayloadAsync", LogConstant.SUCCESS, "Member match payload generation completed.", queueData);
                _log.LogInformation(logMessage);                
                // FetchUMBFromResponseAsync(output,_log);
            }
            catch (Exception e)
            {
                logMessage = Utils.CreateLogMessageObject( "InsertDetailsIntoJsonPayloadAsync", LogConstant.FAILED, "Failed to create member match payload. Error Detials: "+e.Message.ToString(), queueData);
                _log.LogError(logMessage);
                await Utils.UpdateQueue(queueMessage, queueData, StatusConstant.PROCESS_FAILED, "Failed to create member match payload.Error Detials: "+e.Message.ToString(), _log);
                await Utils.UpdateResponseQueueAndDeleteRequestQueue(queueMessage, queueData,_log);
                Utils utils = new Utils();
                utils.RemoveTask(queueMessage.MessageId);
            }
            //finally
            //{
            //    logMessage = Utils.CreateLogMessageObject( "InsertDetailsIntoJsonPayloadAsync", "Information", "Exiting InsertDetailsIntoJsonPayload method.", queueData);
            //    _log.LogInformation(logMessage);
            //}
            return output;
        }
        /// <summary>
        /// This method fetches system and UMB of the member from the CF Apigee api call
        /// </summary>
        /// <param name="jsonPayload"></param>
        /// <param name="accessToken"></param>
        /// <param name="queueMessage"></param>
        /// <param name="queueData"></param>
        /// <param name="_log"></param>
        /// <returns></returns>
        public static async Task<string> FetchUMBFromResponseAsync(string jsonPayload, string accessToken, TQueueMessage queueMessage, Data queueData, ILogger _log)
        {
            string logMessage = Utils.CreateLogMessageObject( "FetchUMBFromResponseAsync", LogConstant.STARTED, "Calling member match api.", queueData);
            _log.LogInformation(logMessage);
            var UMB = "";
            var system = "";
            string systemValue = null;
            JObject jsonObj = null;
            try
            {
                using (HttpClient httpClient = new HttpClient())
                {
                    httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, Environment.GetEnvironmentVariable("URLCFExternalPayer") +"/match/member-match");
                    request.Content = new StringContent(jsonPayload, Encoding.UTF8, "application/json");//CONTENT-TYPE header
                    HttpContent httpContent = new StringContent(jsonPayload, Encoding.UTF8, "application/json");
                    httpContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                    httpClient.DefaultRequestHeaders.TryAddWithoutValidation("content-type", "application/json; charset=utf-8");
                    httpClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {accessToken}");
                    httpClient.DefaultRequestHeaders.Add("cf-payer-registrationid", queueData.OtherPayerId);
                    await httpClient.SendAsync(request).ContinueWith(task =>
                    {
                        var t = task.Result;
                        var t1 = task.Result.Content;
                        var stringData = task.Result.Content.ReadAsStringAsync();
                        jsonObj = JObject.Parse(stringData.Result);
                        var t2 = task.ToString();
                        //  Console.WriteLine($"Response {jsonObj}");
                    });
                }

                var parameterArray = jsonObj.GetValue("parameter") as JArray;
                if (parameterArray != null)
                {
                    //To fetch UMB and system from the response received.
                    foreach (var res in parameterArray.Select(x => x["resource"]["identifier"]))
                    {
                        if (res[0]["type"]["coding"][0]["code"].ToString() == "UMB")
                        {
                            UMB = res[0]["value"].ToString();
                            system = res[0]["system"].ToString();
                        }
                    }
                     logMessage = 
                        Utils.CreateLogMessageObject( "FetchUMBFromResponseAsync", LogConstant.SUCCESS,
                        "Fetched UMB and System values succesfully. UMB: "+UMB+" System: "+system, queueData);
                    _log.LogInformation(logMessage);
                   // _log.LogInformation("UMB: " + UMB + " \nStystem: " + system);
                     systemValue = system + "|" + UMB;
                   // systemValue = UMB;
                   
                }
                else
                {
                    var issueArray = jsonObj.GetValue("issue") as JArray;
                    var code = issueArray[0]["diagnostics"].ToString();// to fetch error code from the diagnostics field of the response
                    logMessage = Utils.CreateLogMessageObject( "FetchUMBFromResponseAsync", LogConstant.FAILED, "Unable to fetch UMB and System values, error code:"+code.ToString(), queueData);
                    _log.LogError(logMessage);
                    await Utils.UpdateQueue(queueMessage, queueData, StatusConstant.TERMINATED, "Unable to fetch UMB and System values.", _log);
                    await Utils.UpdateResponseQueueAndDeleteRequestQueue(queueMessage, queueData,_log);
                    Utils utils = new Utils();
                    utils.RemoveTask(queueMessage.MessageId);
                }

            }
            catch (Exception e)
            {
                logMessage = Utils.CreateLogMessageObject( "FetchUMBFromResponseAsync", LogConstant.ERROR, "Error in member match. Error Detials: " + e.Message.ToString(), queueData);
                _log.LogError(logMessage);                
                await Utils.UpdateQueue(queueMessage, queueData, StatusConstant.PROCESS_FAILED, "Error in member match. Error Detials: " + e.Message.ToString(), _log);
                await Utils.UpdateResponseQueueAndDeleteRequestQueue(queueMessage, queueData,_log);
                Utils utils = new Utils();
                utils.RemoveTask(queueMessage.MessageId);
            }
            //finally
            //{
            //    logMessage = Utils.CreateLogMessageObject( "FetchUMBFromResponseAsync", "Information", "Exiting FetchUMBFromResponseAsync method.", queueData);
            //    _log.LogInformation(logMessage);
            //}
            return systemValue;
        }
        /// <summary>
        /// This method gets the Fhir id of the member by calling the patient identifier api
        /// </summary>
        /// <param name="token"></param>
        /// <param name="systemValue"></param>
        /// <param name="queueMessage"></param>
        /// <param name="queueData"></param>
        /// <param name="_log"></param>
        /// <returns></returns>
        public static async Task GetFhirIDAsync(string token, string systemValue, TQueueMessage queueMessage, Data queueData, ILogger _log)
        {
            string logMessage = Utils.CreateLogMessageObject( "GetFhirIDAsync", LogConstant.STARTED, "Calling patient identifier api.", queueData);
            _log.LogInformation(logMessage);            
            var fhirId = "";
            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                client.DefaultRequestHeaders.Add("cf-payer-registrationid", queueData.OtherPayerId);
                var response = client.GetAsync(Environment.GetEnvironmentVariable("URLCFExternalPayer") + "/Patient?identifier="+systemValue
                );
                try
                {
                    response.Result.EnsureSuccessStatusCode();
                    var jsonString = response.Result.Content.ReadAsStringAsync();
                    var jsonObj = JObject.Parse(jsonString.Result);
                    var entryArray = jsonObj.GetValue("entry") as JArray;

                    foreach (var res in entryArray.Select(x => x["resource"]))
                    {
                        if (!string.IsNullOrEmpty(res["id"].ToString()))
                        {
                            fhirId = res["id"].ToString();
                            logMessage = Utils.CreateLogMessageObject("GetFhirIDAsync", LogConstant.SUCCESS, "Fetched FhirID successfully. Fhir ID :" + fhirId, queueData);
                            _log.LogInformation(logMessage);
                            queueData.PeFhirId = fhirId;
                            await Utils.UpdateQueue(queueMessage, queueData, StatusConstant.PROCESS_DONE, fhirId, _log);
                            await Utils.UpdateResponseQueueAndDeleteRequestQueue(queueMessage, queueData, _log);
                            Utils utils = new Utils();
                            utils.RemoveTask(queueMessage.MessageId);
                        }
                        else
                        {                            
                            logMessage = Utils.CreateLogMessageObject("GetFhirIDAsync", LogConstant.SUCCESS, "Fhir ID of member not found.", queueData);
                            _log.LogInformation(logMessage);
                            await Utils.UpdateQueue(queueMessage, queueData, StatusConstant.TERMINATED, "Fhir ID of member not found.", _log);
                            await Utils.UpdateResponseQueueAndDeleteRequestQueue(queueMessage, queueData, _log);
                            Utils utils = new Utils();
                            utils.RemoveTask(queueMessage.MessageId);
                        }
                    }

                    
                }
                catch (Exception e)
                {
                    logMessage = Utils.CreateLogMessageObject("GetFhirIDAsync", LogConstant.ERROR, "Error in patient identifier call. Error Detials: " + e.Message.ToString(), queueData);
                    _log.LogError(logMessage);
                    await Utils.UpdateQueue(queueMessage, queueData, StatusConstant.PROCESS_FAILED, "Error in patient identifier call. Error Detials: " + e.Message.ToString(), _log);
                    await Utils.UpdateResponseQueueAndDeleteRequestQueue(queueMessage, queueData,_log);
                    Utils utils = new Utils();
                    utils.RemoveTask(queueMessage.MessageId);
                }
                //finally
                //{
                //    logMessage = Utils.CreateLogMessageObject( "GetFhirIDAsync", "Information", "Exiting GetFhirId method", queueData);
                //    _log.LogInformation(logMessage);                    
                //}
            }
           
        }
    }
}





